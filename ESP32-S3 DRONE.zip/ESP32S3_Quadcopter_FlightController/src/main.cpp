#include <Arduino.h>
#include <esp_task_wdt.h>
#include <cmath>
#include "../include/config_pins.h"
#include "../include/flight_types.h"
#include "drivers/mpu6500_drv.h"
#include "drivers/esc_pwm_drv.h"
#include "drivers/gps_neo6m_drv.h"
#include "control/ahrs_madgwick.h"
#include "control/pid_mixer.h"
#include "calibration/auto_calibrator.h"
#include "telemetry/web_portal.h"

// ============================================================================
// GLOBAL SYSTEM INSTANCES
// ============================================================================
MPU6500Driver         g_imu;
ESCPWMDriver          g_esc;
GPSNeo6MDriver        g_gps;
MadgwickAHRS          g_ahrs;
QuadXMixer            g_mixer;
CascadePIDController  g_pid_roll;
CascadePIDController  g_pid_pitch;
CascadePIDController  g_pid_yaw;
AutoCalibrator        g_calibrator;
WebPortal             g_web_portal;

// Flight State & Shared Inter-Core Data
volatile FlightMode   g_flight_mode = MODE_DISARMED;
EulerAngles           g_current_angles;
Vector3f              g_filtered_gyro;
Vector3f              g_filtered_accel;
uint16_t              g_motor_pwms[4] = { 1000, 1000, 1000, 1000 };
GPSStatus             g_gps_status;
BatteryStatus         g_battery_status;
FailsafeReason        g_failsafe_reason = FAILSAFE_REASON_NONE;
int8_t                g_failed_motor_idx = -1;

// Return-To-Home & Landing State Machine
uint32_t              g_land_start_ms = 0;
uint16_t              g_land_throttle = 1420;

// 8MB Octal PSRAM Blackbox Circular Buffer
static const size_t   BLACKBOX_BUFFER_SIZE = 100000; // ~3.2MB in PSRAM
BlackboxRecord*       g_blackbox_buffer = nullptr;
volatile size_t       g_blackbox_head = 0;

// FreeRTOS Task Handles
TaskHandle_t hTaskFlightControl = nullptr;
TaskHandle_t hTaskGPS           = nullptr;
TaskHandle_t hTaskTelemetry     = nullptr;
TaskHandle_t hTaskBlackbox      = nullptr;

// ============================================================================
// HELPER: Normalize angle error to [-180, +180] degrees
// ============================================================================
static float wrap_180(float angle_deg) {
    while (angle_deg > 180.0f)  angle_deg -= 360.0f;
    while (angle_deg < -180.0f) angle_deg += 360.0f;
    return angle_deg;
}

// ============================================================================
// CORE 1: REAL-TIME FLIGHT CONTROL TASK (500Hz Loop - Cycle: 2000us)
// ============================================================================
void Task_FlightControl(void* pvParameters) {
    (void)pvParameters;

    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xFrequency = pdMS_TO_TICKS(2); // 2ms = 500Hz
    const float dt = 0.002f;

    Serial.printf("[CORE 1] Task_FlightControl running on Core %d @ 500Hz (Priority: %d)\n",
                  xPortGetCoreID(), uxTaskPriorityGet(nullptr));

    while (true) {
        uint32_t now_ms = millis();

        // 1. Read MPU6500 data (400kHz I2C + Biquad LPF)
        if (g_imu.read_filtered(g_filtered_accel, g_filtered_gyro)) {
            // 2. Madgwick AHRS sensor fusion
            g_ahrs.update_dt(g_filtered_gyro.x, g_filtered_gyro.y, g_filtered_gyro.z,
                             g_filtered_accel.x, g_filtered_accel.y, g_filtered_accel.z, dt);
            g_current_angles = g_ahrs.get_euler_angles();

            // 3. Read latest RC joystick command from Web Portal
            RCCommand rc;
            g_web_portal.get_latest_rc_command(rc);

            // Handle Arm / Disarm commands
            if (rc.armed && g_flight_mode == MODE_DISARMED) {
                g_esc.set_armed(true);
                g_flight_mode = MODE_STABILIZE_ANGLE;
                g_failsafe_reason = FAILSAFE_REASON_NONE;
                g_failed_motor_idx = -1;
                g_mixer.reset_fault_detector();
                Serial.println("[FLIGHT] ARMED! Entering MODE_STABILIZE_ANGLE");
            } else if (!rc.armed && g_flight_mode != MODE_DISARMED && g_flight_mode != MODE_CALIBRATING) {
                g_esc.emergency_stop();
                g_flight_mode = MODE_DISARMED;
                g_failsafe_reason = FAILSAFE_REASON_NONE;
                Serial.println("[FLIGHT] DISARMED!");
            }

            // 4. Watchdog & Failsafe Checks (Signal Lost, Battery Critical)
            if (g_flight_mode == MODE_STABILIZE_ANGLE) {
                // Check Wi-Fi / RC Signal Timeout (> 2.0s silence)
                if (g_web_portal.is_rc_signal_timed_out(now_ms, 2000)) {
                    g_failsafe_reason = FAILSAFE_REASON_LOST_SIGNAL;
                    if (g_gps_status.home_locked && g_gps_status.has_fix) {
                        g_flight_mode = MODE_RETURN_TO_HOME;
                        Serial.println("[FAILSAFE] RC SIGNAL LOST! Triggering Auto Return-To-Home (RTH)");
                    } else {
                        g_flight_mode = MODE_FAILSAFE_LAND;
                        g_land_start_ms = now_ms;
                        g_land_throttle = 1420;
                        Serial.println("[FAILSAFE] RC SIGNAL LOST (No GPS Home)! Triggering Safe Auto-Land");
                    }
                }

                // Check Critical Battery (< 6.6V)
                if (g_battery_status.is_critical) {
                    g_failsafe_reason = FAILSAFE_REASON_LOW_BATTERY;
                    if (g_gps_status.home_locked && g_gps_status.has_fix) {
                        g_flight_mode = MODE_RETURN_TO_HOME;
                        Serial.println("[FAILSAFE] CRITICAL BATTERY! Auto Returning Home");
                    } else {
                        g_flight_mode = MODE_FAILSAFE_LAND;
                        g_land_start_ms = now_ms;
                        g_land_throttle = 1420;
                        Serial.println("[FAILSAFE] CRITICAL BATTERY! Emergency Landing");
                    }
                }

                // User triggered RTH button on Web Station
                if (rc.rth_requested) {
                    if (g_gps_status.home_locked && g_gps_status.has_fix) {
                        g_flight_mode = MODE_RETURN_TO_HOME;
                        Serial.println("[RTH] User activated Return-To-Home");
                    } else {
                        g_flight_mode = MODE_FAILSAFE_LAND;
                        g_land_start_ms = now_ms;
                        g_land_throttle = 1420;
                        Serial.println("[RTH] No GPS Home locked. Initiating Auto-Land in place");
                    }
                }
            }

            // 5. Motor Failure Detection (1-in-4 motor disconnected / burned out)
            if (g_flight_mode == MODE_STABILIZE_ANGLE || g_flight_mode == MODE_RETURN_TO_HOME) {
                int8_t failed_idx = g_mixer.detect_motor_failure(g_motor_pwms, g_filtered_gyro.x, g_filtered_gyro.y, dt);
                if (failed_idx >= 0) {
                    g_failed_motor_idx = failed_idx;
                    g_flight_mode = MODE_MOTOR_FAIL_DESCENT;
                    g_failsafe_reason = FAILSAFE_REASON_MOTOR_FAILURE;
                    g_land_start_ms = now_ms;
                    Serial.printf("[FAULT-TOLERANT] Motor %d Desynced! Initiating Controlled 3-Motor Spin Descent\n",
                                  failed_idx + 1);
                }
            }

            // 6. Extreme Tilt Protection
            if (g_flight_mode != MODE_DISARMED && g_flight_mode != MODE_MOTOR_FAIL_DESCENT) {
                if (std::abs(g_current_angles.roll) > 45.0f || std::abs(g_current_angles.pitch) > 45.0f) {
                    g_esc.emergency_stop();
                    g_flight_mode = MODE_EMERGENCY_STOP;
                    g_failsafe_reason = FAILSAFE_REASON_CRITICAL_TILT;
                    Serial.println("[SAFETY] CRITICAL TILT LIMIT EXCEEDED (>45 deg) -> KILLED ALL MOTORS");
                }
            }

            // 7. State Machine Execution & Motor Mixing
            if (g_calibrator.get_stage() != CALIB_STAGE_IDLE &&
                g_calibrator.get_stage() != CALIB_STAGE_COMPLETE &&
                g_calibrator.get_stage() != CALIB_STAGE_FAILED) {
                // Auto-Calibration running (Stage 3 capped at safe 50-60% throttle)
                g_calibrator.tick(now_ms, g_filtered_accel, g_filtered_gyro, g_current_angles);
                g_esc.get_current_pwms(g_motor_pwms);

            } else if (g_flight_mode == MODE_STABILIZE_ANGLE) {
                // Normal RC Flycam Joystick Control (Mode 2)
                uint16_t throttle_in = rc.throttle_us > 1050 ? (rc.throttle_us - 1000) : 0;
                float target_roll  = rc.roll_deg;
                float target_pitch = rc.pitch_deg;
                float target_yaw_rate = rc.yaw_rate_dps;

                float roll_out  = g_pid_roll.update(target_roll, g_current_angles.roll, g_filtered_gyro.x, dt);
                float pitch_out = g_pid_pitch.update(target_pitch, g_current_angles.pitch, g_filtered_gyro.y, dt);
                float yaw_out   = g_pid_yaw.update_rate(target_yaw_rate, g_filtered_gyro.z, dt);

                g_mixer.compute(throttle_in, roll_out, pitch_out, yaw_out, true, g_motor_pwms);
                g_esc.write_all_us(g_motor_pwms);

            } else if (g_flight_mode == MODE_RETURN_TO_HOME) {
                // Waypoint Return-To-Home Autonavigation
                if (g_gps_status.distance_to_home_m < 3.0) {
                    // Arrived above home! Switch to landing
                    g_flight_mode = MODE_FAILSAFE_LAND;
                    g_land_start_ms = now_ms;
                    g_land_throttle = 1420;
                    Serial.println("[RTH] Arrived above Home Waypoint! Descending for Auto-Land");
                } else {
                    // Align yaw heading to Home Waypoint
                    float yaw_err = wrap_180(static_cast<float>(g_gps_status.bearing_to_home_deg) - g_current_angles.yaw);
                    float target_yaw_rate = std::max(-50.0f, std::min(50.0f, yaw_err * 1.5f));
                    float target_pitch = -6.0f; // Tilt nose forward ~6 deg to cruise home
                    float target_roll  = 0.0f;
                    uint16_t cruise_throttle = 450; // ~1450us hover

                    float roll_out  = g_pid_roll.update(target_roll, g_current_angles.roll, g_filtered_gyro.x, dt);
                    float pitch_out = g_pid_pitch.update(target_pitch, g_current_angles.pitch, g_filtered_gyro.y, dt);
                    float yaw_out   = g_pid_yaw.update_rate(target_yaw_rate, g_filtered_gyro.z, dt);

                    g_mixer.compute(cruise_throttle, roll_out, pitch_out, yaw_out, true, g_motor_pwms);
                    g_esc.write_all_us(g_motor_pwms);
                }

            } else if (g_flight_mode == MODE_FAILSAFE_LAND) {
                // Soft Auto-Land Descent: Level drone and gently reduce throttle
                if (g_land_start_ms == 0) {
                    g_land_start_ms = now_ms;
                    g_land_throttle = 1420;
                }

                // Decrement throttle gently every 100ms
                static uint32_t last_step_ms = 0;
                if (now_ms - last_step_ms > 100) {
                    last_step_ms = now_ms;
                    if (g_land_throttle > 1080) {
                        g_land_throttle -= 4; // ~40us per second descent rate
                    } else {
                        // Landed! Disarm
                        g_esc.emergency_stop();
                        g_flight_mode = MODE_DISARMED;
                        Serial.println("[LAND] Touchdown detected. Motors disarmed safely!");
                    }
                }

                float roll_out  = g_pid_roll.update(0.0f, g_current_angles.roll, g_filtered_gyro.x, dt);
                float pitch_out = g_pid_pitch.update(0.0f, g_current_angles.pitch, g_filtered_gyro.y, dt);
                float yaw_out   = g_pid_yaw.update_rate(0.0f, g_filtered_gyro.z, dt);

                uint16_t throt_cmd = g_land_throttle > 1000 ? (g_land_throttle - 1000) : 0;
                g_mixer.compute(throt_cmd, roll_out, pitch_out, yaw_out, true, g_motor_pwms);
                g_esc.write_all_us(g_motor_pwms);

            } else if (g_flight_mode == MODE_MOTOR_FAIL_DESCENT) {
                // 3-Motor Emergency Controlled Spin Descent
                // Quadcopter spins like a sycamore seed in a flat orientation while descending
                static uint32_t last_spin_step = 0;
                static uint16_t spin_throttle = 1420;
                if (now_ms - last_spin_step > 150) {
                    last_spin_step = now_ms;
                    if (spin_throttle > 1150) {
                        spin_throttle -= 5;
                    } else {
                        g_esc.emergency_stop();
                        g_flight_mode = MODE_DISARMED;
                    }
                }

                g_mixer.compute_3motor_emergency(spin_throttle, g_failed_motor_idx,
                                                 g_filtered_gyro.x, g_filtered_gyro.y, g_motor_pwms);
                g_esc.write_all_us(g_motor_pwms);

            } else if (g_flight_mode == MODE_DISARMED || g_flight_mode == MODE_EMERGENCY_STOP) {
                g_esc.emergency_stop();
                g_esc.get_current_pwms(g_motor_pwms);
            }
        }

        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

// ============================================================================
// CORE 0: TASK GPS (10Hz Loop)
// ============================================================================
void Task_GPS(void* pvParameters) {
    (void)pvParameters;

    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xFrequency = pdMS_TO_TICKS(100); // 100ms = 10Hz

    Serial.printf("[CORE 0] Task_GPS running on Core %d @ 10Hz\n", xPortGetCoreID());

    while (true) {
        g_gps.update();
        g_gps.get_status(g_gps_status);

        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

// ============================================================================
// CORE 0: TASK TELEMETRY & WEB UI (20Hz Loop)
// ============================================================================
void Task_Telemetry_WebUI(void* pvParameters) {
    (void)pvParameters;

    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xFrequency = pdMS_TO_TICKS(50); // 50ms = 20Hz

    Serial.printf("[CORE 0] Task_Telemetry_WebUI running on Core %d @ 20Hz\n", xPortGetCoreID());

    while (true) {
        // Battery calculation (Nominal LiPo 2S 7.4V, warning < 7.0V, critical < 6.6V)
        // If an ADC voltage divider is connected, analogRead can be wired here.
        g_battery_status.cell_v = g_battery_status.voltage_v / 2.0f;
        g_battery_status.is_warning  = (g_battery_status.voltage_v < 7.0f);
        g_battery_status.is_critical = (g_battery_status.voltage_v < 6.6f);
        float pct = ((g_battery_status.voltage_v - 6.6f) / (8.4f - 6.6f)) * 100.0f;
        g_battery_status.percentage = static_cast<uint8_t>(std::max(0.0f, std::min(100.0f, pct)));

        g_web_portal.tick(g_current_angles, g_filtered_gyro, g_filtered_accel,
                          g_gps_status, g_motor_pwms, g_flight_mode,
                          g_battery_status, g_failsafe_reason, g_failed_motor_idx);

        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

// ============================================================================
// CORE 0: TASK BLACKBOX RECORDER (50Hz Loop to 8MB Octal PSRAM)
// ============================================================================
void Task_Blackbox(void* pvParameters) {
    (void)pvParameters;

    TickType_t xLastWakeTime = xTaskGetTickCount();
    const TickType_t xFrequency = pdMS_TO_TICKS(20); // 20ms = 50Hz

    Serial.printf("[CORE 0] Task_Blackbox running on Core %d @ 50Hz\n", xPortGetCoreID());

    while (true) {
        if (g_blackbox_buffer != nullptr) {
            BlackboxRecord rec;
            rec.timestamp_us = micros();
            rec.roll_cdeg  = static_cast<int16_t>(g_current_angles.roll * 100.0f);
            rec.pitch_cdeg = static_cast<int16_t>(g_current_angles.pitch * 100.0f);
            rec.yaw_cdeg   = static_cast<int16_t>(g_current_angles.yaw * 100.0f);

            rec.gyro_raw[0] = static_cast<int16_t>(g_filtered_gyro.x * 10.0f);
            rec.gyro_raw[1] = static_cast<int16_t>(g_filtered_gyro.y * 10.0f);
            rec.gyro_raw[2] = static_cast<int16_t>(g_filtered_gyro.z * 10.0f);

            rec.accel_raw[0] = static_cast<int16_t>(g_filtered_accel.x * 1000.0f);
            rec.accel_raw[1] = static_cast<int16_t>(g_filtered_accel.y * 1000.0f);
            rec.accel_raw[2] = static_cast<int16_t>(g_filtered_accel.z * 1000.0f);

            for (int i = 0; i < 4; i++) {
                rec.motor_pwm[i] = g_motor_pwms[i];
            }
            rec.flight_mode = static_cast<uint8_t>(g_flight_mode);
            rec.flags = static_cast<uint8_t>(g_failsafe_reason);

            g_blackbox_buffer[g_blackbox_head] = rec;
            g_blackbox_head = (g_blackbox_head + 1) % BLACKBOX_BUFFER_SIZE;
        }

        vTaskDelayUntil(&xLastWakeTime, xFrequency);
    }
}

// ============================================================================
// SYSTEM SETUP
// ============================================================================
void setup() {
    Serial.begin(115200);
    delay(1000);

    Serial.println("\n=======================================================");
    Serial.println("  ESP32-S3 N16R8 QUADCOPTER FLIGHT CONTROLLER STARTING");
    Serial.println("=======================================================");

    // Verify PSRAM (8MB Octal PSRAM)
    if (psramInit()) {
        size_t psram_size = esp_spiram_get_size();
        Serial.printf("[PSRAM] Found Octal PSRAM: %u bytes (%u MB)\n", psram_size, psram_size / (1024 * 1024));

        g_blackbox_buffer = (BlackboxRecord*)ps_malloc(BLACKBOX_BUFFER_SIZE * sizeof(BlackboxRecord));
        if (g_blackbox_buffer) {
            Serial.printf("[BLACKBOX] Allocated %u records (%u KB) in PSRAM\n",
                          BLACKBOX_BUFFER_SIZE, (BLACKBOX_BUFFER_SIZE * sizeof(BlackboxRecord)) / 1024);
        } else {
            Serial.println("[BLACKBOX] WARNING: Failed to allocate PSRAM blackbox buffer");
        }
    } else {
        Serial.println("[PSRAM] ERROR: PSRAM initialization failed!");
    }

    // 1. Initialize MPU6500 (GPIO 8 SDA, GPIO 9 SCL, GPIO 10 INT @ 400kHz)
    if (!g_imu.init(IMU_SDA_PIN, IMU_SCL_PIN, IMU_INT_PIN)) {
        Serial.println("[INIT] CRITICAL: Failed to initialize MPU6500!");
    }

    // 2. Initialize 4 ESC PWM Channels (GPIO 4, 5, 6, 7 @ 400Hz 14-bit)
    if (!g_esc.init()) {
        Serial.println("[INIT] CRITICAL: Failed to initialize ESC PWM driver!");
    }

    // 3. Initialize NEO-6M GPS (GPIO 18 RX, GPIO 17 TX @ 9600 baud)
    g_gps.init(GPS_RX_PIN, GPS_TX_PIN, GPS_BAUDRATE);

    // 4. Initialize AHRS & Control Algorithms
    g_ahrs.init(500.0f, 0.1f);

    // Configure default PID gains
    PIDConfig angle_cfg(4.0f, 0.0f, 0.0f, 0.0f, 300.0f);
    PIDConfig rate_cfg(1.2f, 0.05f, 0.02f, 100.0f, 400.0f);
    g_pid_roll.set_configs(angle_cfg, rate_cfg);
    g_pid_pitch.set_configs(angle_cfg, rate_cfg);
    g_pid_yaw.set_configs(PIDConfig(2.0f, 0.0f, 0.0f, 0.0f, 200.0f),
                          PIDConfig(1.5f, 0.02f, 0.0f, 50.0f, 300.0f));

    // 5. Initialize Auto-Calibrator
    g_calibrator.init(&g_imu, &g_esc);
    g_mixer.set_calibration_profile(g_calibrator.get_profile());

    // 6. Initialize Wi-Fi Web Telemetry Station with Dual Joysticks
    g_web_portal.init(&g_calibrator, &g_esc, &g_pid_roll, &g_pid_pitch, &g_pid_yaw);

    // 7. Spawn FreeRTOS Tasks on Dual Cores
    // Core 1: Real-Time Flight Core (Priority: 5)
    xTaskCreatePinnedToCore(Task_FlightControl, "FlightControl", 8192, nullptr, 5, &hTaskFlightControl, 1);

    // Core 0: Navigation, Telemetry & Blackbox
    xTaskCreatePinnedToCore(Task_GPS, "GPS", 4096, nullptr, 2, &hTaskGPS, 0);
    xTaskCreatePinnedToCore(Task_Telemetry_WebUI, "WebUI", 8192, nullptr, 3, &hTaskTelemetry, 0);
    xTaskCreatePinnedToCore(Task_Blackbox, "Blackbox", 4096, nullptr, 1, &hTaskBlackbox, 0);

    Serial.println("[SYSTEM] All FreeRTOS Dual-Core Tasks Started Successfully!");
}

void loop() {
    vTaskDelay(pdMS_TO_TICKS(1000));
}
