#ifndef WEB_PORTAL_H
#define WEB_PORTAL_H

#include <stdint.h>
#include <stdbool.h>
#include "../../include/flight_types.h"

// Forward declarations
class AutoCalibrator;
class ESCPWMDriver;
class CascadePIDController;

class WebPortal {
public:
    WebPortal();

    bool init(AutoCalibrator* calibrator, ESCPWMDriver* esc,
              CascadePIDController* pid_roll,
              CascadePIDController* pid_pitch,
              CascadePIDController* pid_yaw);

    // Call periodically in Core 0 (e.g. 20Hz)
    void tick(const EulerAngles& angles,
              const Vector3f& gyro,
              const Vector3f& accel,
              const GPSStatus& gps,
              const uint16_t motor_pwms[4],
              FlightMode mode,
              const BatteryStatus& battery,
              FailsafeReason failsafe_reason,
              int8_t failed_motor_idx);

    bool is_client_connected() const { return m_clients_connected > 0; }

    // Read current RC Virtual Stick inputs received over WebSocket
    void get_latest_rc_command(RCCommand& cmd);

    // Failsafe watchdog: check if RC signal has been silent for > timeout_ms
    bool is_rc_signal_timed_out(uint32_t now_ms, uint32_t timeout_ms = 2000) const;

    void update_rc_command(uint16_t throttle, float yaw_rate, float pitch, float roll, bool arm, bool rth);

private:
    AutoCalibrator*       m_calibrator;
    ESCPWMDriver*         m_esc;
    CascadePIDController* m_pid_roll;
    CascadePIDController* m_pid_pitch;
    CascadePIDController* m_pid_yaw;

    uint8_t   m_clients_connected;
    uint32_t  m_last_broadcast_ms;

    RCCommand m_latest_rc;
};

#endif // WEB_PORTAL_H
