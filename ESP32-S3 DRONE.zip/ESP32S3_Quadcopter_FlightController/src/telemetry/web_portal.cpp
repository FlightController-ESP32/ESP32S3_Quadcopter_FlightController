#include "web_portal.h"
#include "../calibration/auto_calibrator.h"
#include "../drivers/esc_pwm_drv.h"
#include "../control/pid_mixer.h"

#ifdef ARDUINO
#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <pgmspace.h>

static const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>ESP32-S3 Flycam Remote Station</title>
    <style>
        :root {
            --bg: #0b0f19; --card: #151d30; --accent: #0ea5e9;
            --danger: #ef4444; --warning: #f59e0b; --success: #10b981;
            --text: #f8fafc; --muted: #64748b; --border: #1e293b;
        }
        * { box-sizing: border-box; margin: 0; padding: 0; user-select: none; -webkit-user-select: none; }
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: var(--bg); color: var(--text); overflow-x: hidden; touch-action: manipulation; }
        
        /* Top Navigation & Status Bar */
        .status-bar {
            display: flex; justify-content: space-between; align-items: center;
            padding: 8px 12px; background: #070a12; border-bottom: 1px solid var(--border);
            font-size: 0.8rem;
        }
        .status-group { display: flex; align-items: center; gap: 8px; }
        .pill { padding: 3px 8px; border-radius: 999px; font-weight: bold; font-size: 0.72rem; }
        .pill-batt { background: #064e3b; color: #34d399; }
        .pill-gps { background: #1e3a8a; color: #60a5fa; }
        .pill-mode { background: #7f1d1d; color: #fca5a5; }

        /* Main Container */
        .container { max-width: 900px; margin: 0 auto; padding: 8px; }

        /* Telemetry & 3D Cards */
        .grid-top { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 8px; }
        @media(max-width: 600px) { .grid-top { grid-template-columns: 1fr; } }
        .card { background: var(--card); border: 1px solid var(--border); border-radius: 8px; padding: 10px; }
        .card h3 { font-size: 0.85rem; color: var(--accent); margin-bottom: 6px; border-bottom: 1px solid var(--border); padding-bottom: 4px; display: flex; justify-content: space-between; }
        
        /* 3D Attitude Indicator */
        .viewport { width: 100%; height: 110px; perspective: 400px; display: flex; align-items: center; justify-content: center; background: #060911; border-radius: 6px; }
        .drone-box { width: 70px; height: 70px; position: relative; transform-style: preserve-3d; transition: transform 0.04s linear; }
        .drone-arm { position: absolute; background: #475569; }
        .arm-x { width: 70px; height: 4px; top: 33px; left: 0; }
        .arm-y { width: 4px; height: 70px; top: 0; left: 33px; }
        .drone-center { position: absolute; width: 26px; height: 26px; background: #0284c7; top: 22px; left: 22px; border-radius: 4px; font-size: 8px; font-weight: bold; color: white; display: flex; align-items: center; justify-content: center; }
        .prop { position: absolute; width: 16px; height: 16px; border-radius: 50%; border: 2px dashed var(--accent); }
        .p1 { top: -6px; left: -6px; border-color: #ef4444; }
        .p2 { top: -6px; right: -6px; border-color: #10b981; }
        .p3 { bottom: -6px; right: -6px; border-color: #ef4444; }
        .p4 { bottom: -6px; left: -6px; border-color: #10b981; }

        .row { display: flex; justify-content: space-between; font-size: 0.78rem; padding: 2px 0; }
        .val { font-family: monospace; font-weight: bold; color: var(--accent); }

        /* Banner Alerts */
        .alert-banner { display: none; background: #b91c1c; color: white; padding: 6px 10px; border-radius: 6px; font-size: 0.8rem; font-weight: bold; text-align: center; margin-bottom: 8px; animation: pulse 1s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }

        /* RC Joystick Controller Area */
        .rc-panel {
            background: #090d16; border: 1px solid var(--border); border-radius: 12px;
            padding: 10px; margin-top: 6px;
        }
        .rc-title { font-size: 0.8rem; color: var(--muted); text-align: center; margin-bottom: 8px; }
        .joystick-grid {
            display: flex; justify-content: space-around; align-items: center; gap: 10px;
        }
        .stick-wrapper {
            display: flex; flex-direction: column; align-items: center;
        }
        .stick-label { font-size: 0.72rem; color: var(--accent); margin-bottom: 4px; font-weight: bold; }
        .joystick-base {
            width: 140px; height: 140px; background: radial-gradient(circle, #1e293b 20%, #0f172a 80%);
            border: 2px solid #334155; border-radius: 50%; position: relative; touch-action: none;
            display: flex; align-items: center; justify-content: center;
            box-shadow: inset 0 0 15px rgba(0,0,0,0.6);
        }
        .crosshair-h { position: absolute; width: 100%; height: 1px; background: rgba(255,255,255,0.1); }
        .crosshair-v { position: absolute; height: 100%; width: 1px; background: rgba(255,255,255,0.1); }
        .joystick-knob {
            width: 48px; height: 48px; background: radial-gradient(circle, #38bdf8, #0284c7);
            border: 2px solid #fff; border-radius: 50%; position: absolute;
            box-shadow: 0 4px 10px rgba(0,0,0,0.5); pointer-events: none;
            transform: translate(0px, 0px);
        }

        /* Flight Action Buttons */
        .action-grid {
            display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 10px;
        }
        .btn-action {
            padding: 12px; border: none; border-radius: 8px; font-weight: bold;
            font-size: 0.85rem; cursor: pointer; text-align: center;
        }
        .btn-arm { background: #15803d; color: white; }
        .btn-arm.armed { background: #b91c1c; }
        .btn-rth { background: #d97706; color: white; }
        .btn-rth.active { background: #e11d48; }

        /* Secondary actions */
        .btn-sub { width: 100%; padding: 8px; border: 1px solid var(--border); border-radius: 6px; background: #1e293b; color: #94a3b8; font-size: 0.75rem; font-weight: bold; margin-top: 6px; cursor: pointer; }
    </style>
</head>
<body>
    <div class="status-bar">
        <div class="status-group">
            <span class="pill pill-mode" id="badgeMode">DISARMED</span>
            <span class="pill pill-batt" id="badgeBatt">7.4V (2S) 100%</span>
        </div>
        <div class="status-group">
            <span class="pill pill-gps" id="badgeGPS">GPS: 0 sats (No Fix)</span>
            <span id="pingStatus" style="color:var(--success);">● LIVE</span>
        </div>
    </div>

    <div class="container">
        <!-- Emergency / Motor Desync Alert Banner -->
        <div class="alert-banner" id="motorFailAlert">
            ⚠️ CẢNH BÁO: MẤT ĐỘNG CƠ! KÍCH HOẠT QUAY CÂN BẰNG TỰ ĐỘNG HẠ CÁNH (SPIN DESCENT)
        </div>

        <div class="grid-top">
            <!-- 3D Drone Attitude -->
            <div class="card">
                <h3>THÁI ĐỘ BAY (AHRS 3D) <span id="rpyVal" class="val">0° / 0° / 0°</span></h3>
                <div class="viewport">
                    <div class="drone-box" id="drone3D">
                        <div class="drone-arm arm-x"></div>
                        <div class="drone-arm arm-y"></div>
                        <div class="drone-center">+X</div>
                        <div class="prop p1"></div>
                        <div class="prop p2"></div>
                        <div class="prop p3"></div>
                        <div class="prop p4"></div>
                    </div>
                </div>
                <div class="row" style="margin-top:6px;"><span>Gia tốc Accel (X,Y,Z):</span><span class="val" id="accelTxt">0, 0, 1.0g</span></div>
                <div class="row"><span>Vận tốc góc Gyro:</span><span class="val" id="gyroTxt">0, 0, 0 dps</span></div>
            </div>

            <!-- GPS Waypoint & Return-To-Home -->
            <div class="card">
                <h3>ĐỊNH VỊ VỆ TINH (WAYPOINT NHÀ) <span id="gpsDistTxt" class="val">Cách Home: --</span></h3>
                <div class="row"><span>Tọa độ hiện tại:</span><span class="val" id="gpsCurPos">0.000000, 0.000000</span></div>
                <div class="row"><span>Tọa độ Waypoint Nhà:</span><span class="val" id="gpsHomePos">Chưa khóa</span></div>
                <div class="row"><span>Độ cao / Vận tốc:</span><span class="val" id="gpsAltSpd">0.0m | 0.0 km/h</span></div>
                <div class="row"><span>Góc phương vị về Nhà:</span><span class="val" id="gpsBearing">--°</span></div>
                <div class="row"><span>PWM Motor (1,2,3,4):</span><span class="val" id="pwmTxt">1000, 1000, 1000, 1000</span></div>
            </div>
        </div>

        <!-- DUAL VIRTUAL JOYSTICK (RC MODE 2) -->
        <div class="rc-panel">
            <div class="rc-title">TAY ĐIỀU KHIỂN FLYCAM 2 CẦN (RC MODE 2 VIRTUAL STICKS)</div>
            <div class="joystick-grid">
                <!-- Left Stick: Throttle (Vertical) + Yaw (Horizontal) -->
                <div class="stick-wrapper">
                    <span class="stick-label">TAY TRÁI: GA (LÊN/XUỐNG) & XOAY (TRÁI/PHẢI)</span>
                    <div class="joystick-base" id="leftBase">
                        <div class="crosshair-h"></div>
                        <div class="crosshair-v"></div>
                        <div class="joystick-knob" id="leftKnob"></div>
                    </div>
                    <span style="font-size:0.7rem; color:var(--muted); margin-top:4px;" id="leftStickTxt">Ga: 0% | Xoay: 0°/s</span>
                </div>

                <!-- Right Stick: Pitch (Advance/Back) + Roll (Left/Right) -->
                <div class="stick-wrapper">
                    <span class="stick-label">TAY PHẢI: TIẾN/LÙI & NGHIÊNG TRÁI/PHẢI</span>
                    <div class="joystick-base" id="rightBase">
                        <div class="crosshair-h"></div>
                        <div class="crosshair-v"></div>
                        <div class="joystick-knob" id="rightKnob"></div>
                    </div>
                    <span style="font-size:0.7rem; color:var(--muted); margin-top:4px;" id="rightStickTxt">Pitch: 0° | Roll: 0°</span>
                </div>
            </div>

            <!-- Big Main Action Buttons -->
            <div class="action-grid">
                <button class="btn-action btn-arm" id="btnArm" onclick="toggleArm()">KHỞI ĐỘNG (ARM MOTORS)</button>
                <button class="btn-action btn-rth" id="btnRTH" onclick="toggleRTH()">VỀ NHÀ (RETURN TO HOME)</button>
            </div>

            <button class="btn-sub" onclick="triggerCalibSafe()">TỰ CĂN CHỈNH ĐỘNG CƠ (AUTO-CALIBRATE - AN TOÀN 50-60% GA)</button>
        </div>
    </div>

    <script>
        let ws;
        let isArmed = false;
        let isRTH = false;

        // Stick states:
        // Left: throt_us (1000..2000), yaw_dps (-150..+150)
        let rcThrottle = 1000;
        let rcYawRate = 0;
        // Right: pitch_deg (-25..+25), roll_deg (-25..+25)
        let rcPitch = 0;
        let rcRoll = 0;

        function connectWS() {
            ws = new WebSocket("ws://" + location.hostname + ":81/");
            ws.onopen = () => {
                document.getElementById('pingStatus').innerText = "● LIVE";
                document.getElementById('pingStatus').style.color = "var(--success)";
            };
            ws.onclose = () => {
                document.getElementById('pingStatus').innerText = "● MẤT SÓNG";
                document.getElementById('pingStatus').style.color = "var(--danger)";
                setTimeout(connectWS, 1000);
            };
            ws.onmessage = (e) => {
                try {
                    const d = JSON.parse(e.data);
                    // 3D Visualizer
                    const drone = document.getElementById('drone3D');
                    drone.style.transform = `rotateX(${-d.pitch}deg) rotateY(${d.roll}deg) rotateZ(${d.yaw}deg)`;
                    document.getElementById('rpyVal').innerText = `${d.roll.toFixed(1)}° / ${d.pitch.toFixed(1)}° / ${d.yaw.toFixed(1)}°`;
                    document.getElementById('accelTxt').innerText = `${d.ax.toFixed(2)}, ${d.ay.toFixed(2)}, ${d.az.toFixed(2)}g`;
                    document.getElementById('gyroTxt').innerText = `${d.gx.toFixed(0)}, ${d.gy.toFixed(0)}, ${d.gz.toFixed(0)} dps`;

                    // Flight Mode & Battery
                    document.getElementById('badgeMode').innerText = d.flight_mode_str;
                    document.getElementById('badgeBatt').innerText = `${d.batt_v.toFixed(1)}V (${d.batt_pct}%)`;
                    if (d.batt_v < 6.6) {
                        document.getElementById('badgeBatt').style.background = "#7f1d1d";
                    } else if (d.batt_v < 7.0) {
                        document.getElementById('badgeBatt').style.background = "#78350f";
                    } else {
                        document.getElementById('badgeBatt').style.background = "#064e3b";
                    }

                    // GPS & Waypoint Home
                    document.getElementById('badgeGPS').innerText = `GPS: ${d.gps_sats} sats ${d.gps_fix ? '(3D Fix)' : '(Tìm kiếm)'}`;
                    document.getElementById('gpsCurPos').innerText = `${d.gps_lat.toFixed(6)}, ${d.gps_lon.toFixed(6)}`;
                    document.getElementById('gpsHomePos').innerText = d.gps_home_locked ? `${d.home_lat.toFixed(6)}, ${d.home_lon.toFixed(6)}` : "Chưa khóa";
                    document.getElementById('gpsDistTxt').innerText = `Cách Home: ${d.gps_home_dist.toFixed(1)}m`;
                    document.getElementById('gpsAltSpd').innerText = `${d.gps_alt.toFixed(1)}m | ${d.gps_spd.toFixed(1)} km/h`;
                    document.getElementById('gpsBearing').innerText = `${d.gps_bearing.toFixed(1)}°`;
                    document.getElementById('pwmTxt').innerText = d.pwms.join(', ') + " us";

                    // Motor failure alert
                    const failBanner = document.getElementById('motorFailAlert');
                    if (d.failed_motor >= 0) {
                        failBanner.style.display = "block";
                        failBanner.innerText = `⚠️ CẢNH BÁO: MOTOR ${d.failed_motor + 1} MẤT TÍN HIỆU! ĐANG QUAY TRÒN CÂN BẰNG TỰ ĐỘNG HẠ CÁNH`;
                    } else {
                        failBanner.style.display = "none";
                    }
                } catch(err) {}
            };
        }
        connectWS();

        // Send RC command at 30Hz
        setInterval(() => {
            if (ws && ws.readyState === WebSocket.OPEN) {
                const pkt = {
                    cmd: "rc",
                    throt: rcThrottle,
                    yaw: rcYawRate,
                    pitch: rcPitch,
                    roll: rcRoll,
                    armed: isArmed,
                    rth: isRTH
                };
                ws.send(JSON.stringify(pkt));
            }
        }, 33);

        // --- DUAL VIRTUAL JOYSTICK IMPLEMENTATION ---
        function setupJoystick(baseId, knobId, onMove, onRelease) {
            const base = document.getElementById(baseId);
            const knob = document.getElementById(knobId);
            const radius = 50; // max travel radius
            let touchId = null;

            function handleStart(e) {
                for (let i = 0; i < e.changedTouches.length; i++) {
                    const t = e.changedTouches[i];
                    const rect = base.getBoundingClientRect();
                    if (t.clientX >= rect.left && t.clientX <= rect.right &&
                        t.clientY >= rect.top && t.clientY <= rect.bottom) {
                        touchId = t.identifier;
                        moveKnob(t.clientX, t.clientY, rect);
                        break;
                    }
                }
            }

            function handleMove(e) {
                if (touchId === null) return;
                for (let i = 0; i < e.changedTouches.length; i++) {
                    const t = e.changedTouches[i];
                    if (t.identifier === touchId) {
                        const rect = base.getBoundingClientRect();
                        moveKnob(t.clientX, t.clientY, rect);
                        break;
                    }
                }
            }

            function handleEnd(e) {
                if (touchId === null) return;
                for (let i = 0; i < e.changedTouches.length; i++) {
                    if (e.changedTouches[i].identifier === touchId) {
                        touchId = null;
                        knob.style.transform = `translate(0px, 0px)`;
                        if (onRelease) onRelease();
                        break;
                    }
                }
            }

            function moveKnob(clientX, clientY, rect) {
                const centerX = rect.left + rect.width / 2;
                const centerY = rect.top + rect.height / 2;
                let dx = clientX - centerX;
                let dy = clientY - centerY;
                const dist = Math.sqrt(dx * dx + dy * dy);
                if (dist > radius) {
                    dx = (dx / dist) * radius;
                    dy = (dy / dist) * radius;
                }
                knob.style.transform = `translate(${dx}px, ${dy}px)`;
                // Normalized -1.0 to +1.0
                const normX = dx / radius;
                const normY = -dy / radius; // Invert Y so up is positive
                if (onMove) onMove(normX, normY);
            }

            base.addEventListener('touchstart', handleStart, { passive: false });
            window.addEventListener('touchmove', handleMove, { passive: false });
            window.addEventListener('touchend', handleEnd, { passive: false });
            window.addEventListener('touchcancel', handleEnd, { passive: false });
        }

        // Setup Left Stick: Throttle (Y) + Yaw (X)
        setupJoystick('leftBase', 'leftKnob', (normX, normY) => {
            // Yaw: -150 to +150 deg/s
            rcYawRate = normX * 150.0;
            // Throttle: 1000us to 2000us (Center is 1500us hover)
            // normY: -1 to +1 -> maps to 1000 to 2000
            rcThrottle = Math.round(1500 + normY * 500);
            rcThrottle = Math.max(1000, Math.min(2000, rcThrottle));
            const pct = Math.round(((rcThrottle - 1000) / 1000) * 100);
            document.getElementById('leftStickTxt').innerText = `Ga: ${pct}% (${rcThrottle}us) | Xoay: ${rcYawRate.toFixed(0)}°/s`;
        }, () => {
            // Spring return for Yaw
            rcYawRate = 0.0;
            // Throttle remains or idles depending on arm
            if (!isArmed) rcThrottle = 1000;
            document.getElementById('leftStickTxt').innerText = `Ga: 0% | Xoay: 0°/s`;
        });

        // Setup Right Stick: Pitch (Y) + Roll (X)
        setupJoystick('rightBase', 'rightKnob', (normX, normY) => {
            // Roll: -25 to +25 deg (X)
            rcRoll = normX * 25.0;
            // Pitch: -25 to +25 deg (Y: push up is pitch nose DOWN/forward, so pitch = -normY * 25)
            rcPitch = -normY * 25.0;
            document.getElementById('rightStickTxt').innerText = `Pitch: ${rcPitch.toFixed(1)}° | Roll: ${rcRoll.toFixed(1)}°`;
        }, () => {
            // Both spring return to 0 (Level flight)
            rcRoll = 0.0;
            rcPitch = 0.0;
            document.getElementById('rightStickTxt').innerText = `Pitch: 0° | Roll: 0°`;
        });

        function toggleArm() {
            isArmed = !isArmed;
            const btn = document.getElementById('btnArm');
            if (isArmed) {
                btn.innerText = "NGẮT GA (DISARM)";
                btn.classList.add('armed');
            } else {
                btn.innerText = "KHỞI ĐỘNG (ARM MOTORS)";
                btn.classList.remove('armed');
                rcThrottle = 1000;
            }
        }

        function toggleRTH() {
            isRTH = !isRTH;
            const btn = document.getElementById('btnRTH');
            if (isRTH) {
                btn.innerText = "ĐANG VỀ NHÀ (HỦY RTH)";
                btn.classList.add('active');
            } else {
                btn.innerText = "VỀ NHÀ (RETURN TO HOME)";
                btn.classList.remove('active');
            }
        }

        function triggerCalibSafe() {
            if (confirm("KÍCH HOẠT TỰ CĂN CHỈNH 4 MOTOR (Đã giới hạn công suất an toàn 50%-60% ga, chống cháy motor & nổ ESC)?")) {
                fetch("/api/calibrate", { method: "POST" });
            }
        }
    </script>
</body>
</html>
)rawliteral";

static WebServer server(80);
static WebSocketsServer wsServer(81);
#endif

WebPortal::WebPortal()
    : m_calibrator(nullptr), m_esc(nullptr),
      m_pid_roll(nullptr), m_pid_pitch(nullptr), m_pid_yaw(nullptr),
      m_clients_connected(0), m_last_broadcast_ms(0) {
    m_latest_rc = RCCommand();
}

bool WebPortal::init(AutoCalibrator* calibrator, ESCPWMDriver* esc,
                     CascadePIDController* pid_roll,
                     CascadePIDController* pid_pitch,
                     CascadePIDController* pid_yaw) {
    m_calibrator = calibrator;
    m_esc = esc;
    m_pid_roll = pid_roll;
    m_pid_pitch = pid_pitch;
    m_pid_yaw = pid_yaw;

#ifdef ARDUINO
    WiFi.mode(WIFI_AP);
    WiFi.softAP("ESP32S3_DRONE_FC", "12345678");
    Serial.println("[WIFI] Access Point 'ESP32S3_DRONE_FC' started at 192.168.4.1");

    server.on("/", HTTP_GET, []() {
        server.send_P(200, "text/html", INDEX_HTML);
    });

    server.on("/api/calibrate", HTTP_POST, [this]() {
        if (m_calibrator) {
            m_calibrator->start_calibration();
            server.send(200, "application/json", "{\"status\":\"started\"}");
        } else {
            server.send(500, "application/json", "{\"error\":\"no calibrator\"}");
        }
    });

    server.on("/api/disarm", HTTP_POST, [this]() {
        if (m_esc) m_esc->emergency_stop();
        m_latest_rc.armed = false;
        m_latest_rc.throttle_us = 1000;
        server.send(200, "application/json", "{\"status\":\"disarmed\"}");
    });

    server.begin();

    wsServer.begin();
    wsServer.onEvent([this](uint8_t num, WStype_t type, uint8_t* payload, size_t length) {
        (void)length;
        if (type == WStype_CONNECTED) {
            m_clients_connected++;
        } else if (type == WStype_DISCONNECTED) {
            if (m_clients_connected > 0) m_clients_connected--;
        } else if (type == WStype_TEXT) {
            // Parse incoming RC joystick command
            // Format: {"cmd":"rc","throt":1500,"yaw":0,"pitch":0,"roll":0,"armed":true,"rth":false}
            const char* msg = reinterpret_cast<const char*>(payload);
            const char* cmd_ptr = strstr(msg, "\"cmd\":\"rc\"");
            if (cmd_ptr != nullptr) {
                uint16_t throt = 1000;
                float yaw = 0.0f, pitch = 0.0f, roll = 0.0f;
                bool arm = false, rth = false;

                const char* p;
                if ((p = strstr(msg, "\"throt\":")) != nullptr) throt = atoi(p + 8);
                if ((p = strstr(msg, "\"yaw\":"))   != nullptr) yaw   = atof(p + 6);
                if ((p = strstr(msg, "\"pitch\":")) != nullptr) pitch = atof(p + 8);
                if ((p = strstr(msg, "\"roll\":"))  != nullptr) roll  = atof(p + 7);
                if ((p = strstr(msg, "\"armed\":true")) != nullptr) arm = true;
                if ((p = strstr(msg, "\"rth\":true"))   != nullptr) rth = true;

                update_rc_command(throt, yaw, pitch, roll, arm, rth);
            }
        }
    });

    Serial.println("[WEB] Telemetry Station with Dual Joysticks & RTH ready on ports 80 & 81");
#endif
    return true;
}

void WebPortal::update_rc_command(uint16_t throttle, float yaw_rate, float pitch, float roll, bool arm, bool rth) {
    m_latest_rc.throttle_us   = throttle;
    m_latest_rc.yaw_rate_dps  = yaw_rate;
    m_latest_rc.pitch_deg     = pitch;
    m_latest_rc.roll_deg      = roll;
    m_latest_rc.armed         = arm;
    m_latest_rc.rth_requested = rth;
#ifdef ARDUINO
    m_latest_rc.timestamp_ms  = millis();
#endif
}

void WebPortal::get_latest_rc_command(RCCommand& cmd) {
    cmd = m_latest_rc;
}

bool WebPortal::is_rc_signal_timed_out(uint32_t now_ms, uint32_t timeout_ms) const {
    if (m_latest_rc.timestamp_ms == 0) return true;
    return (now_ms - m_latest_rc.timestamp_ms > timeout_ms);
}

void WebPortal::tick(const EulerAngles& angles,
                     const Vector3f& gyro,
                     const Vector3f& accel,
                     const GPSStatus& gps,
                     const uint16_t motor_pwms[4],
                     FlightMode mode,
                     const BatteryStatus& battery,
                     FailsafeReason failsafe_reason,
                     int8_t failed_motor_idx) {
#ifdef ARDUINO
    server.handleClient();
    wsServer.loop();

    uint32_t now = millis();
    if (now - m_last_broadcast_ms >= 50) { // 20Hz update
        m_last_broadcast_ms = now;

        const char* mode_str = "DISARMED";
        switch (mode) {
            case MODE_CALIBRATING:        mode_str = "TỰ CĂN CHỈNH"; break;
            case MODE_ACRO_RATE:          mode_str = "ACRO RATE"; break;
            case MODE_STABILIZE_ANGLE:    mode_str = "CÂN BẰNG TỰ ĐỘNG"; break;
            case MODE_RETURN_TO_HOME:     mode_str = "ĐANG VỀ NHÀ (RTH)"; break;
            case MODE_FAILSAFE_LAND:      mode_str = "HẠ CÁNH KHẨN CẤP"; break;
            case MODE_MOTOR_FAIL_DESCENT: mode_str = "QUAY RƠI CÂN BẰNG (3-MOTOR)"; break;
            case MODE_EMERGENCY_STOP:     mode_str = "NGẮT TOÀN BỘ (KILL)"; break;
            default: break;
        }

        char json[512];
        std::snprintf(json, sizeof(json),
            "{\"roll\":%.2f,\"pitch\":%.2f,\"yaw\":%.2f,"
            "\"gx\":%.1f,\"gy\":%.1f,\"gz\":%.1f,"
            "\"ax\":%.2f,\"ay\":%.2f,\"az\":%.2f,"
            "\"flight_mode_str\":\"%s\","
            "\"batt_v\":%.2f,\"batt_pct\":%d,"
            "\"gps_fix\":%s,\"gps_sats\":%d,\"gps_lat\":%.6f,\"gps_lon\":%.6f,\"gps_alt\":%.1f,\"gps_spd\":%.1f,"
            "\"home_lat\":%.6f,\"home_lon\":%.6f,\"gps_home_locked\":%s,\"gps_home_dist\":%.1f,\"gps_bearing\":%.1f,"
            "\"pwms\":[%d,%d,%d,%d],\"failed_motor\":%d,\"failsafe\":%d}",
            angles.roll, angles.pitch, angles.yaw,
            gyro.x, gyro.y, gyro.z,
            accel.x, accel.y, accel.z,
            mode_str,
            battery.voltage_v, battery.percentage,
            gps.has_fix ? "true" : "false", gps.satellites, gps.latitude, gps.longitude, gps.altitude_m, gps.speed_kmh,
            gps.home_lat, gps.home_lon, gps.home_locked ? "true" : "false", gps.distance_to_home_m, gps.bearing_to_home_deg,
            motor_pwms[0], motor_pwms[1], motor_pwms[2], motor_pwms[3],
            failed_motor_idx, static_cast<int>(failsafe_reason));

        wsServer.broadcastTXT(json);
    }
#else
    (void)angles; (void)gyro; (void)accel; (void)gps; (void)motor_pwms;
    (void)mode; (void)battery; (void)failsafe_reason; (void)failed_motor_idx;
#endif
}
