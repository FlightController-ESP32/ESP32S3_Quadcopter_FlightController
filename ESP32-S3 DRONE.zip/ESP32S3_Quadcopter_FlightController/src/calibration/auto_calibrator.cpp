#include "auto_calibrator.h"
#include "../drivers/mpu6500_drv.h"
#include "../drivers/esc_pwm_drv.h"
#include <cstdio>
#include <cstring>
#include <cmath>

#ifdef ARDUINO
#include <Arduino.h>
#include <Preferences.h>
#endif

AutoCalibrator::AutoCalibrator()
    : m_imu(nullptr), m_esc(nullptr),
      m_stage(CALIB_STAGE_IDLE),
      m_progress_percent(0),
      m_emergency_tripped(false),
      m_static_sample_count(0),
      m_sum_gx(0), m_sum_gy(0), m_sum_gz(0),
      m_sum_ax(0), m_sum_ay(0), m_sum_az(0),
      m_test_motor_idx(0), m_motor_substep(0),
      m_current_ramp_pwm(1000), m_step_start_time_ms(0),
      m_noise_floor_rms(0.02f),
      m_thrust_ramp_start_ms(0),
      m_pitch_trim_accum(0.0f), m_roll_trim_accum(0.0f) {
    std::snprintf(m_status_message, sizeof(m_status_message), "Idle - Ready for calibration");
    m_profile.reset_to_defaults();
}

void AutoCalibrator::init(MPU6500Driver* imu, ESCPWMDriver* esc) {
    m_imu = imu;
    m_esc = esc;
    load_from_nvs();
}

bool AutoCalibrator::start_calibration() {
    m_stage = CALIB_STAGE_1_STATIC_ZERO;
    m_progress_percent = 0;
    m_emergency_tripped = false;
    m_static_sample_count = 0;
    m_sum_gx = m_sum_gy = m_sum_gz = 0;
    m_sum_ax = m_sum_ay = m_sum_az = 0;

    std::snprintf(m_status_message, sizeof(m_status_message),
                  "Stage 1/4: Keep drone completely stationary for static zero-point calibration...");

    if (m_esc) {
        m_esc->emergency_stop();
    }
    return true;
}

void AutoCalibrator::abort_calibration(const char* reason) {
    m_stage = CALIB_STAGE_FAILED;
    if (m_esc) {
        m_esc->emergency_stop();
    }
    std::snprintf(m_status_message, sizeof(m_status_message), "Calibration Aborted: %s", reason);
}

bool AutoCalibrator::update_safety_check(float roll_deg, float pitch_deg, float angular_rate_dps) {
    // Safety Cutoff Rule from README.pdf:
    // If tilt exceeds +-25 degrees or extreme angular rate (>600 deg/s),
    // immediately shut down all 4 motors to 1000us within 1ms!
    if (std::abs(roll_deg) > 25.0f || std::abs(pitch_deg) > 25.0f || std::abs(angular_rate_dps) > 600.0f) {
        if (m_stage == CALIB_STAGE_2_SPIN_VIBRATION || m_stage == CALIB_STAGE_3_FULL_POWER_THRUST) {
            m_emergency_tripped = true;
            m_stage = CALIB_STAGE_FAILED;
            if (m_esc) {
                m_esc->emergency_stop();
            }
            std::snprintf(m_status_message, sizeof(m_status_message),
                          "EMERGENCY CUTOFF TRIPPED! Roll: %.1f deg, Pitch: %.1f deg", roll_deg, pitch_deg);
            return true;
        }
    }
    return false;
}

void AutoCalibrator::tick(uint32_t current_time_ms,
                          const Vector3f& accel_raw,
                          const Vector3f& gyro_raw,
                          const EulerAngles& current_angles) {
    switch (m_stage) {
        case CALIB_STAGE_1_STATIC_ZERO:
            step_stage_1_static(accel_raw, gyro_raw);
            break;

        case CALIB_STAGE_2_SPIN_VIBRATION:
            step_stage_2_individual_spin(current_time_ms, accel_raw);
            break;

        case CALIB_STAGE_3_FULL_POWER_THRUST:
            step_stage_3_dynamic_thrust(current_time_ms, current_angles, gyro_raw);
            break;

        case CALIB_STAGE_4_NVS_COMMIT:
            step_stage_4_commit();
            break;

        case CALIB_STAGE_IDLE:
        case CALIB_STAGE_COMPLETE:
        case CALIB_STAGE_FAILED:
        default:
            break;
    }
}

void AutoCalibrator::step_stage_1_static(const Vector3f& accel, const Vector3f& gyro) {
    const uint16_t TARGET_SAMPLES = 2000;

    m_sum_gx += gyro.x;
    m_sum_gy += gyro.y;
    m_sum_gz += gyro.z;

    m_sum_ax += accel.x;
    m_sum_ay += accel.y;
    m_sum_az += (accel.z - 1.0f); // 1.0g gravity reference

    m_static_sample_count++;
    m_progress_percent = static_cast<uint8_t>((m_static_sample_count * 25) / TARGET_SAMPLES);

    if (m_static_sample_count >= TARGET_SAMPLES) {
        m_profile.gyro_bias[0] = static_cast<float>(m_sum_gx / TARGET_SAMPLES);
        m_profile.gyro_bias[1] = static_cast<float>(m_sum_gy / TARGET_SAMPLES);
        m_profile.gyro_bias[2] = static_cast<float>(m_sum_gz / TARGET_SAMPLES);

        m_profile.accel_bias[0] = static_cast<float>(m_sum_ax / TARGET_SAMPLES);
        m_profile.accel_bias[1] = static_cast<float>(m_sum_ay / TARGET_SAMPLES);
        m_profile.accel_bias[2] = static_cast<float>(m_sum_az / TARGET_SAMPLES);

        if (m_imu) {
            m_imu->set_calibration(m_profile);
        }

        // Transition to Stage 2
        m_stage = CALIB_STAGE_2_SPIN_VIBRATION;
        m_test_motor_idx = 0;
        m_motor_substep = 0;
        m_current_ramp_pwm = 1000;
        m_step_start_time_ms = 0;
        m_vibration_samples.clear();

        if (m_esc) {
            m_esc->set_armed(true);
        }

        std::snprintf(m_status_message, sizeof(m_status_message),
                      "Stage 2/4: Starting Individual Spin & Vibration Test for Motor 1 (GPIO 4)...");
    }
}

void AutoCalibrator::step_stage_2_individual_spin(uint32_t now_ms, const Vector3f& accel) {
    if (m_test_motor_idx >= 4) {
        // Compute optimal LPF cutoff frequency based on peak vibration
        float max_rms = 0.0f;
        for (int i = 0; i < 4; i++) {
            if (m_profile.peak_vibration_rms[i] > max_rms) {
                max_rms = m_profile.peak_vibration_rms[i];
            }
        }

        // Adapt cutoff frequency:
        // High vibration (> 0.5g RMS) -> Aggressive filter (35Hz - 45Hz)
        // Moderate vibration (0.2g - 0.5g) -> 55Hz - 65Hz
        // Low vibration (< 0.2g) -> 80Hz
        if (max_rms > 0.5f) {
            m_profile.lpf_cutoff_hz = 40.0f;
        } else if (max_rms > 0.2f) {
            m_profile.lpf_cutoff_hz = 60.0f;
        } else {
            m_profile.lpf_cutoff_hz = 80.0f;
        }

        if (m_imu) {
            m_imu->set_filter_cutoff(m_profile.lpf_cutoff_hz);
        }

        if (m_esc) {
            m_esc->emergency_stop();
        }

        // Transition to Stage 3
        m_stage = CALIB_STAGE_3_FULL_POWER_THRUST;
        m_thrust_ramp_start_ms = now_ms;
        m_pitch_trim_accum = 0.0f;
        m_roll_trim_accum = 0.0f;
        if (m_esc) {
            m_esc->set_armed(true);
        }

        std::snprintf(m_status_message, sizeof(m_status_message),
                      "Stage 3/4: Full-Power 4-Motor Ramp (Tether/Gantry Safety Check Active)...");
        return;
    }

    // Accumulate vibration samples
    m_vibration_samples.push_back(accel);
    if (m_vibration_samples.size() > 100) {
        m_vibration_samples.erase(m_vibration_samples.begin());
    }

    if (m_step_start_time_ms == 0) {
        m_step_start_time_ms = now_ms;
    }

    uint16_t motor_pwms[4] = { 1000, 1000, 1000, 1000 };

    if (m_motor_substep == 0) {
        // Deadband Search: Ramp from 1000us up by 2us every 20ms
        if (now_ms - m_step_start_time_ms > 20) {
            m_step_start_time_ms = now_ms;
            m_current_ramp_pwm += 2;

            motor_pwms[m_test_motor_idx] = m_current_ramp_pwm;
            if (m_esc) m_esc->write_all_us(motor_pwms);

            float current_rms = MPU6500Driver::compute_rms_vibration(m_vibration_samples);
            if (current_rms > (m_noise_floor_rms * 2.5f) || m_current_ramp_pwm >= 1150) {
                // Deadband detected
                m_profile.esc_deadband[m_test_motor_idx] = m_current_ramp_pwm;
                m_motor_substep = 1; // Move to 50% power test
                m_step_start_time_ms = now_ms;
            }
        }
    } else if (m_motor_substep == 1) {
        // Safe 35% Power test for 1.5 seconds (1350us)
        motor_pwms[m_test_motor_idx] = 1350;
        if (m_esc) m_esc->write_all_us(motor_pwms);

        if (now_ms - m_step_start_time_ms > 1500) {
            m_motor_substep = 2; // Move to 50%
            m_step_start_time_ms = now_ms;
        }
    } else if (m_motor_substep == 2) {
        // Safe 50% Power test for 1.5 seconds (1500us)
        motor_pwms[m_test_motor_idx] = 1500;
        if (m_esc) m_esc->write_all_us(motor_pwms);

        if (now_ms - m_step_start_time_ms > 1500) {
            m_motor_substep = 3; // Move to safe max 55-60% power test
            m_step_start_time_ms = now_ms;
        }
    } else if (m_motor_substep == 3) {
        // Safe 55%-60% Power test for 1.5 seconds (1550us max to protect ESCs & battery)
        motor_pwms[m_test_motor_idx] = 1550;
        if (m_esc) m_esc->write_all_us(motor_pwms);

        if (now_ms - m_step_start_time_ms > 1500) {
            // Measure peak RMS
            float peak_rms = MPU6500Driver::compute_rms_vibration(m_vibration_samples);
            m_profile.peak_vibration_rms[m_test_motor_idx] = peak_rms;

            // Stop this motor and move to next motor
            motor_pwms[m_test_motor_idx] = 1000;
            if (m_esc) m_esc->write_all_us(motor_pwms);

            m_test_motor_idx++;
            m_motor_substep = 0;
            m_current_ramp_pwm = 1000;
            m_step_start_time_ms = 0;
            m_vibration_samples.clear();

            m_progress_percent = 25 + (m_test_motor_idx * 10);
            std::snprintf(m_status_message, sizeof(m_status_message),
                          "Stage 2/4: Completed Motor %d test, advancing...", m_test_motor_idx);
        }
    }
}

void AutoCalibrator::step_stage_3_dynamic_thrust(uint32_t now_ms,
                                                 const EulerAngles& angles,
                                                 const Vector3f& gyro) {
    uint32_t elapsed = now_ms - m_thrust_ramp_start_ms;
    const uint32_t RAMP_DURATION_MS = 6000; // 6 second ramp test

    if (elapsed > RAMP_DURATION_MS) {
        // Finalize K_Mi factors based on accumulated trims
        // Pitch: M1, M2 are Front; M3, M4 are Rear
        // If nose pitched UP (+pitch), Front motors were too strong -> decrease M1, M2, increase M3, M4
        float pitch_correction = m_pitch_trim_accum * 0.005f;
        float roll_correction  = m_roll_trim_accum  * 0.005f;

        m_profile.motor_thrust_trim[0] = 1.0f - pitch_correction - roll_correction;
        m_profile.motor_thrust_trim[1] = 1.0f - pitch_correction + roll_correction;
        m_profile.motor_thrust_trim[2] = 1.0f + pitch_correction + roll_correction;
        m_profile.motor_thrust_trim[3] = 1.0f + pitch_correction - roll_correction;

        // Bound all trims strictly to [0.85, 1.15]
        for (int i = 0; i < 4; i++) {
            m_profile.motor_thrust_trim[i] = std::max(0.85f, std::min(1.15f, m_profile.motor_thrust_trim[i]));
        }

        if (m_esc) {
            m_esc->emergency_stop();
        }

        m_stage = CALIB_STAGE_4_NVS_COMMIT;
        m_progress_percent = 85;
        std::snprintf(m_status_message, sizeof(m_status_message),
                      "Stage 4/4: Committing calibrated parameters to NVS Flash...");
        return;
    }

    // Safe Ramp: Throttle from 10% (1100us) to capped 55%-60% (1550us max)
    // to strictly protect ESC 5A-8A and 2S battery from overcurrent / burnout
    float throttle_ratio = static_cast<float>(elapsed) / static_cast<float>(RAMP_DURATION_MS);
    uint16_t throttle_pwm = static_cast<uint16_t>(1100 + throttle_ratio * 450); // 1100 -> 1550us max

    // If at capped test throttle (>1400us), observe attitude bias
    if (throttle_pwm > 1400) {
        m_pitch_trim_accum += (angles.pitch + gyro.y * 0.1f);
        m_roll_trim_accum  += (angles.roll  + gyro.x * 0.1f);
    }

    uint16_t pwms[4];
    for (int i = 0; i < 4; i++) {
        pwms[i] = throttle_pwm;
    }
    if (m_esc) {
        m_esc->write_all_us(pwms);
    }

    m_progress_percent = 65 + static_cast<uint8_t>(throttle_ratio * 20.0f);
}

void AutoCalibrator::step_stage_4_commit() {
    m_profile.is_valid = true;
    m_profile.checksum = m_profile.calculate_checksum();

    save_to_nvs();

    m_stage = CALIB_STAGE_COMPLETE;
    m_progress_percent = 100;
    std::snprintf(m_status_message, sizeof(m_status_message),
                  "Calibration Finished! K_M: [%.2f, %.2f, %.2f, %.2f], LPF: %.1fHz",
                  m_profile.motor_thrust_trim[0], m_profile.motor_thrust_trim[1],
                  m_profile.motor_thrust_trim[2], m_profile.motor_thrust_trim[3],
                  m_profile.lpf_cutoff_hz);
}

bool AutoCalibrator::load_from_nvs() {
#ifdef ARDUINO
    Preferences prefs;
    if (!prefs.begin("drone_cal", true)) { // Read-only
        Serial.println("[CALIB] No existing NVS calibration found");
        return false;
    }

    size_t len = prefs.getBytes("profile", &m_profile, sizeof(CalibrationProfile));
    prefs.end();

    if (len == sizeof(CalibrationProfile) &&
        m_profile.magic == CALIBRATION_MAGIC &&
        m_profile.calculate_checksum() == m_profile.checksum &&
        m_profile.is_valid) {
        Serial.printf("[CALIB] Successfully loaded NVS profile! LPF: %.1fHz, Trim: [%.2f, %.2f, %.2f, %.2f]\n",
                      m_profile.lpf_cutoff_hz,
                      m_profile.motor_thrust_trim[0], m_profile.motor_thrust_trim[1],
                      m_profile.motor_thrust_trim[2], m_profile.motor_thrust_trim[3]);
        if (m_imu) m_imu->set_calibration(m_profile);
        return true;
    } else {
        Serial.println("[CALIB] Invalid or corrupt NVS profile. Resetting to defaults.");
        m_profile.reset_to_defaults();
        return false;
    }
#else
    m_profile.reset_to_defaults();
    return true;
#endif
}

bool AutoCalibrator::save_to_nvs() {
#ifdef ARDUINO
    Preferences prefs;
    if (!prefs.begin("drone_cal", false)) { // Read-write
        Serial.println("[CALIB] ERROR: Failed to open NVS namespace");
        return false;
    }

    m_profile.checksum = m_profile.calculate_checksum();
    size_t written = prefs.putBytes("profile", &m_profile, sizeof(CalibrationProfile));
    prefs.end();

    if (written == sizeof(CalibrationProfile)) {
        Serial.println("[CALIB] Profile successfully committed to ESP32 Flash!");
        return true;
    } else {
        Serial.println("[CALIB] ERROR: Incomplete NVS write!");
        return false;
    }
#else
    return true;
#endif
}
