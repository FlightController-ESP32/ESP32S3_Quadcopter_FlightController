#ifndef ESC_PWM_DRV_H
#define ESC_PWM_DRV_H

#include <stdint.h>
#include <stdbool.h>
#include "../../include/config_pins.h"
#include "../../include/flight_types.h"

// ============================================================================
// 4-CHANNEL ESC PWM DRIVER (LEDC HARDWARE ACCELERATED)
// ============================================================================

class ESCPWMDriver {
public:
    ESCPWMDriver();

    // Initialize 4 channels on GPIO 4, 5, 6, 7 @ 400Hz, 14-bit resolution
    bool init();

    // Write pulse width to individual motor (motor_idx: 0..3 -> M1..M4)
    void write_motor_us(uint8_t motor_idx, uint16_t pulse_us);

    // Atomic update of all 4 motors
    void write_all_us(const uint16_t motor_pwms[4]);

    // Read current output pulse widths
    void get_current_pwms(uint16_t motor_pwms[4]) const;

    // Safety: Emergency Cutoff (< 1ms) -> Set all motors to ESC_MIN_PULSE_US (1000us)
    void emergency_stop();

    // Standard ESC Endpoint Calibration Routine (1000us - 2000us)
    void run_endpoint_calibration();

    // Safety checks
    bool is_armed() const { return m_armed; }
    void set_armed(bool armed);

private:
    uint32_t us_to_duty(uint16_t pulse_us) const;

    static const uint8_t MOTOR_PINS[4];
    static const uint8_t LEDC_CHANNELS[4];

    uint16_t m_current_pwms[4];
    bool m_armed;
    bool m_initialized;
};

#endif // ESC_PWM_DRV_H
