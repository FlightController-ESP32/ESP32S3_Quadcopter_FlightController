#ifndef GPS_NEO6M_DRV_H
#define GPS_NEO6M_DRV_H

#include <stdint.h>
#include <stdbool.h>
#include "../../include/config_pins.h"
#include "../../include/flight_types.h"

#ifdef ARDUINO
#include <TinyGPSPlus.h>
#include <HardwareSerial.h>
#endif

// ============================================================================
// U-BLOX NEO-6M GPS DRIVER (UART2)
// ============================================================================

class GPSNeo6MDriver {
public:
    GPSNeo6MDriver();

    bool init(uint8_t rx_pin = GPS_RX_PIN, uint8_t tx_pin = GPS_TX_PIN, uint32_t baudrate = GPS_BAUDRATE);
    void update();

    bool has_valid_fix() const { return m_status.has_fix; }
    uint8_t get_satellites() const { return m_status.satellites; }
    void get_status(GPSStatus& status) const { status = m_status; }

    // Distance in meters to locked home point
    double get_distance_to_home_m() const;
    // Course bearing in degrees to home point
    double get_bearing_to_home_deg() const;

    void set_home_location(double lat, double lon, float alt);

private:
    GPSStatus m_status;

#ifdef ARDUINO
    TinyGPSPlus m_gps;
    HardwareSerial m_serial;
#endif
};

#endif // GPS_NEO6M_DRV_H
