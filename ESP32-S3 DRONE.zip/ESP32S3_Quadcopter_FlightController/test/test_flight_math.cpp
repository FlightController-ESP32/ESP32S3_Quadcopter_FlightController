#include <iostream>
#include <cassert>
#include <cmath>
#include <vector>
#include "../include/flight_types.h"
#include "../include/config_pins.h"
#include "../src/control/ahrs_madgwick.h"
#include "../src/control/pid_mixer.h"
#include "../src/drivers/mpu6500_drv.h"
#include "../src/calibration/auto_calibrator.h"

#define ASSERT_NEAR(val, expected, eps) \
    assert(std::fabs((val) - (expected)) <= (eps) && #val " is not near expected")

void test_biquad_lpf() {
    std::cout << "[TEST] Running Biquad LPF tests..." << std::endl;
    BiquadLPF filter;
    filter.init(60.0f, 500.0f); // 60Hz cutoff, 500Hz sampling rate

    // Test DC response (constant signal of 10.0)
    float out = 0.0f;
    for (int i = 0; i < 100; i++) {
        out = filter.apply(10.0f);
    }
    ASSERT_NEAR(out, 10.0f, 0.05f);

    // Test high frequency motor vibration attenuation (200Hz sine wave on 500Hz sampling)
    float max_high_freq = 0.0f;
    for (int i = 0; i < 200; i++) {
        float high_freq_sample = 5.0f * std::sin(2.0f * M_PI * 200.0f * (i / 500.0f));
        float f_out = filter.apply(high_freq_sample);
        if (i > 100 && std::fabs(f_out) > max_high_freq) {
            max_high_freq = std::fabs(f_out);
        }
    }
    // High frequency 200Hz should be attenuated by > 75% (< 1.25 when input amplitude is 5.0)
    assert(max_high_freq < 1.25f);
    std::cout << "[PASS] Biquad LPF passes DC unity gain and high-frequency attenuation!" << std::endl;
}

void test_madgwick_ahrs() {
    std::cout << "[TEST] Running Madgwick AHRS sensor fusion tests..." << std::endl;
    MadgwickAHRS ahrs;
    ahrs.init(500.0f, 0.1f); // 500Hz, beta = 0.1

    // Simulate resting completely flat: Accel = (0, 0, 1.0g), Gyro = (0, 0, 0)
    for (int i = 0; i < 500; i++) {
        ahrs.update(0.0f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f);
    }

    EulerAngles angles = ahrs.get_euler_angles();
    ASSERT_NEAR(angles.roll, 0.0f, 0.5f);
    ASSERT_NEAR(angles.pitch, 0.0f, 0.5f);

    // Quaternion magnitude invariant
    Quaternion4f q = ahrs.get_quaternion();
    float mag = std::sqrt(q.q0*q.q0 + q.q1*q.q1 + q.q2*q.q2 + q.q3*q.q3);
    ASSERT_NEAR(mag, 1.0f, 0.001f);

    // Test pitch tilt: tilt nose up 30 degrees (NED body frame: Accel X = -sin(30) = -0.5, Accel Z = cos(30) = 0.866)
    for (int i = 0; i < 3000; i++) {
        ahrs.update(0.0f, 0.0f, 0.0f, -0.5f, 0.0f, 0.866f);
    }
    angles = ahrs.get_euler_angles();
    ASSERT_NEAR(angles.pitch, 30.0f, 1.0f);
    ASSERT_NEAR(angles.roll, 0.0f, 0.5f);
    ASSERT_NEAR(angles.roll, 0.0f, 0.5f);

    std::cout << "[PASS] Madgwick AHRS converges accurately to gravity vector without drift!" << std::endl;
}

void test_cascade_pid_and_mixer() {
    std::cout << "[TEST] Running Cascade PID and Quad-X Mixer tests..." << std::endl;

    PIDConfig angle_cfg(4.0f, 0.0f, 0.0f, 0.0f, 300.0f);     // Outer angle PID
    PIDConfig rate_cfg(1.2f, 0.05f, 0.02f, 100.0f, 400.0f);   // Inner rate PID

    CascadePIDController pid_roll(angle_cfg, rate_cfg);
    CascadePIDController pid_pitch(angle_cfg, rate_cfg);
    CascadePIDController pid_yaw(PIDConfig(2.0f, 0.0f, 0.0f, 0.0f, 200.0f),
                                PIDConfig(1.5f, 0.02f, 0.0f, 50.0f, 300.0f));

    // Reset PID states
    pid_roll.reset();
    pid_pitch.reset();
    pid_yaw.reset();

    // Quad-X Mixer test
    QuadXMixer mixer;
    CalibrationProfile profile;
    profile.reset_to_defaults();

    // Custom deadbands and trim gains to test scaling
    profile.esc_deadband[0] = 1040;
    profile.esc_deadband[1] = 1050;
    profile.esc_deadband[2] = 1060;
    profile.esc_deadband[3] = 1045;
    profile.motor_thrust_trim[0] = 1.05f; // M1 slightly trimmed up (+5%)
    profile.motor_thrust_trim[1] = 0.95f; // M2 trimmed down (-5%)
    profile.motor_thrust_trim[2] = 1.00f;
    profile.motor_thrust_trim[3] = 1.00f;
    mixer.set_calibration_profile(profile);

    // Test 1: Disarmed / Zero throttle
    uint16_t motor_pwms[4];
    mixer.compute(0, 0.0f, 0.0f, 0.0f, false, motor_pwms);
    for (int i = 0; i < 4; i++) {
        assert(motor_pwms[i] == ESC_MIN_PULSE_US); // Must be 1000us when disarmed
    }

    // Test 2: Armed with 500us throttle, perfectly level (PIDs output 0)
    mixer.compute(500, 0.0f, 0.0f, 0.0f, true, motor_pwms);
    // M1: deadband 1040 + 1.05 * 500 = 1040 + 525 = 1565us
    // M2: deadband 1050 + 0.95 * 500 = 1050 + 475 = 1525us
    // M3: deadband 1060 + 1.00 * 500 = 1060 + 500 = 1560us
    // M4: deadband 1045 + 1.00 * 500 = 1045 + 500 = 1545us
    ASSERT_NEAR(motor_pwms[0], 1565, 1);
    ASSERT_NEAR(motor_pwms[1], 1525, 1);
    ASSERT_NEAR(motor_pwms[2], 1560, 1);
    ASSERT_NEAR(motor_pwms[3], 1545, 1);

    // Test 3: Pitch forward command (+Pitch PID = +50)
    // Pitching forward requires rear motors (M3, M4) to increase and front motors (M1, M2) to decrease,
    // OR depending on frame convention:
    // In Quad-X:
    // M1 (Front-Left), M2 (Front-Right), M3 (Rear-Right), M4 (Rear-Left)
    // To pitch nose DOWN / forward (Pitch negative), front motors reduce, rear motors increase.
    // Our Mixer convention:
    // M1 = Throttle + Pitch - Roll - Yaw
    // M2 = Throttle + Pitch + Roll + Yaw
    // M3 = Throttle - Pitch + Roll - Yaw
    // M4 = Throttle - Pitch - Roll + Yaw
    mixer.compute(500, 0.0f, 50.0f, 0.0f, true, motor_pwms);
    // M1 and M2 should have higher value than M3 and M4 with +Pitch
    assert(motor_pwms[0] > 1565);
    assert(motor_pwms[1] > 1525);
    assert(motor_pwms[2] < 1560);
    assert(motor_pwms[3] < 1545);

    std::cout << "[PASS] Cascade PID and Quad-X Mixer pass all test cases!" << std::endl;
}

void test_auto_calibrator_safety() {
    std::cout << "[TEST] Running Auto-Calibrator Safety & Cutoff tests..." << std::endl;
    AutoCalibrator calibrator;
    calibrator.init();

    // Trigger calibration
    calibrator.start_calibration();
    assert(calibrator.get_stage() == CALIB_STAGE_1_STATIC_ZERO);

    // Test Emergency Cutoff when tilt > 25 degrees during Stage 3
    calibrator.force_stage_for_test(CALIB_STAGE_3_FULL_POWER_THRUST);
    
    // Feed normal level attitude (5 degrees tilt) -> should not trigger cutoff
    bool emergency = calibrator.update_safety_check(5.0f, 3.0f, 10.0f);
    assert(!emergency);
    assert(calibrator.get_stage() == CALIB_STAGE_3_FULL_POWER_THRUST);

    // Feed extreme tilt (26.5 degrees tilt > 25 degrees) -> MUST TRIGGER EMERGENCY CUTOFF
    emergency = calibrator.update_safety_check(26.5f, 0.0f, 100.0f);
    assert(emergency);
    assert(calibrator.get_stage() == CALIB_STAGE_FAILED);
    assert(calibrator.is_emergency_cutoff_tripped());

    std::cout << "[PASS] Auto-Calibrator emergency kill switch trips immediately at >25 deg tilt!" << std::endl;
}

void test_motor_failure_and_3motor_recovery() {
    std::cout << "[TEST] Running Motor Failure Detection & 3-Motor Recovery tests..." << std::endl;
    QuadXMixer mixer;
    mixer.reset_fault_detector();

    uint16_t pwms[4] = { 1500, 1500, 1500, 1500 };

    // Test 1: Normal flight -> no failure detected
    for (int i = 0; i < 50; i++) {
        int8_t fail = mixer.detect_motor_failure(pwms, 0.0f, 0.0f, 0.002f);
        assert(fail == -1);
    }

    // Test 2: Motor 1 (Front-Left) desyncs/dies while commanded at 1500us
    // Vehicle rolls left (-45 deg/s) and pitches up (+45 deg/s)
    int8_t detected = -1;
    for (int i = 0; i < 150; i++) { // 150 * 2ms = 300ms
        detected = mixer.detect_motor_failure(pwms, -45.0f, 45.0f, 0.002f);
    }
    assert(detected == 0); // Must identify M1 (index 0) has died!

    // Test 3: 3-Motor Emergency Controlled Spin Mixer
    uint16_t emergency_pwms[4];
    mixer.compute_3motor_emergency(1400, 0, 0.0f, 0.0f, emergency_pwms);

    // M1 must be 1000us (dead motor shut off)
    assert(emergency_pwms[0] == 1000);
    // M3 (opposite) must be scaled down to counter moment (< 1200us)
    assert(emergency_pwms[2] <= 1200);
    // M2 and M4 (adjacent) must carry the lift (> 1300us)
    assert(emergency_pwms[1] >= 1350);
    assert(emergency_pwms[3] >= 1350);

    std::cout << "[PASS] Motor 1 failure detected and 3-motor emergency spin descent mixer verified!" << std::endl;
}

int main() {
    std::cout << "==================================================" << std::endl;
    std::cout << "Running TDD Test Suite for ESP32-S3 Flight Core" << std::endl;
    std::cout << "==================================================" << std::endl;

    test_biquad_lpf();
    test_madgwick_ahrs();
    test_cascade_pid_and_mixer();
    test_auto_calibrator_safety();
    test_motor_failure_and_3motor_recovery();

    std::cout << "==================================================" << std::endl;
    std::cout << "ALL FLIGHT CORE TESTS PASSED (100% GREEN)" << std::endl;
    std::cout << "==================================================" << std::endl;
    return 0;
}
