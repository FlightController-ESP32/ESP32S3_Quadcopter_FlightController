# Dự Án Firmware Quadcopter ESP32-S3 N16R8
### (Auto-Calibration, Dynamic Thrust Trim & Real-Time Flight Control)

Hệ thống Firmware hoàn chỉnh tối ưu hóa thời gian thực (Dual-Core FreeRTOS) dành cho bo mạch **ESP32-S3 N16R8** (16MB Flash, 8MB Octal PSRAM) điều khiển máy bay 4 cánh quạt (Quadcopter Quad-X), cảm biến góc nghiêng **MPU6500 (GY-6500)** qua I2C 400kHz, định vị vệ tinh **GPS NEO-6M** qua UART2, băm xung 4 ESC **LEDC 400Hz**, và trạm điều khiển Telemetry Web 3D qua Wi-Fi Access Point.

---

## 1. SƠ ĐỒ ĐI DÂY CHI TIẾT (WIRING DIAGRAM)

Theo tài liệu thiết kế phần cứng và sơ đồ nguyên lý:

| Linh Kiện | Chân Trên Linh Kiện | Chân ESP32-S3 | Chức Năng / Ghi Chú |
| :--- | :--- | :--- | :--- |
| **MPU6500** | VCC | **3V3** | Nguồn sạch 3.3V từ ESP32-S3 |
| | GND | **GND** | Mass chung |
| | SCL | **GPIO 9** | I2C Clock (Tốc độ 400kHz Fast Mode) |
| | SDA | **GPIO 8** | I2C Data |
| | AD0 | **GND** | Khóa địa chỉ cứng I2C: `0x68` |
| | INT | **GPIO 10** | Ngắt dữ liệu sẵn sàng (Data Ready) |
| **GPS NEO-6M**| VCC | **5V / VIN** | Nguồn 5V từ mạch hạ áp Buck |
| | TXD | **GPIO 18** | Đấu chéo vào RX2 của ESP32-S3 |
| | RXD | **GPIO 17** | Đấu chéo vào TX2 của ESP32-S3 |
| | GND | **GND** | Mass chung |
| **Khối ESC (x4)**| ESC 1 (Motor 1) SIG | **GPIO 4** | Xung PWM 400Hz (Trước - Trái, Quay CW) |
| | ESC 2 (Motor 2) SIG | **GPIO 5** | Xung PWM 400Hz (Trước - Phải, Quay CCW) |
| | ESC 3 (Motor 3) SIG | **GPIO 6** | Xung PWM 400Hz (Sau - Phải, Quay CW) |
| | ESC 4 (Motor 4) SIG | **GPIO 7** | Xung PWM 400Hz (Sau - Trái, Quay CCW) |
| | Dây đen nhỏ (GND)| **GND** | Cả 4 dây nối chung về Mass GND |
| | **Dây đỏ 5V BEC** | **CẮT BỎ (NC)** | **TUYỆT ĐỐI CẮT BỎ ĐỂ TRÁNH XUNG ĐỘT NGUỒN** |
| **Hạ Áp Buck** | IN+ / IN- | **Pin LiPo 2S** | Nguồn pin LiPo 2S (7.4V - 8.4V) |
| | OUT+ (5V 2A) | **5V / VIN** | Cấp nguồn nuôi ESP32-S3 và GPS NEO-6M |
| | OUT- (GND) | **GND** | Mass chung hệ thống |

> [!CAUTION]
> **Ràng Buộc Phần Cứng Bắt Buộc Trên ESP32-S3 N16R8**:
> - **TUYỆT ĐỐI KHÔNG** sử dụng các chân **GPIO 35, GPIO 36, GPIO 37** vì các chân này đã nối nội bộ với chip nhớ **Octal PSRAM 8MB**.
> - Cả 4 dây đỏ BEC 5V ở giắc cắm tín hiệu ESC phải được rút/cắt bỏ (NC).

---

## 2. QUY ƯỚC HÌNH HỌC QUAD-X & MA TRẬN TRỘN LỰC

```
             [ MŨI MÁY BAY (FRONT / +X) ]
                         ^
                         |
      (Motor 1 - CW)     |    (Motor 2 - CCW)
         [GPIO 4]        |       [GPIO 5]
              \          |          /
               \   +-----------+   /
                \  |  MPU6500  |  /
    <-- (-Y Trái) -|    +X ^   |-- (+Y Phải) -->
                /  +-----------+  \
               /         |         \
              /          |          \
         [GPIO 7]        |       [GPIO 6]
     (Motor 4 - CCW)     |    (Motor 3 - CW)
                         |
             [ ĐUÔI MÁY BAY (REAR / -X) ]
```

### Công Thức Trộn Lực & Hệ Số Bù Trim Riêng Từng Động Cơ:
$$\text{PWM}_i = \text{PWM}_{\text{deadband}, i} + K_{Mi} \cdot (\text{Throttle} + \text{PID}_{\text{mixer}, i})$$
Trong đó:
- $K_{Mi} \in [0.85, 1.15]$: Hệ số cân bằng động lực học được học tự động bởi thuật toán `AutoCalibrator`.
- $\text{PWM}_{\text{deadband}, i}$: Ngưỡng khởi động phát hiện rung động cơ của từng chiếc ESC.

---

## 3. CHẾ ĐỘ TỰ CĂN CHỈNH 4 ĐỘNG CƠ (4-STAGE AUTO-TRIM ENGINE)

1. **Giai đoạn 1: Cân bằng tĩnh (Static Zero-Point Calibration)**
   - Lấy 2000 mẫu khi drone nằm yên trên mặt phẳng cân bằng để tính chính xác Offset của Con quay hồi chuyển (Gyro) và Gia tốc kế (Accel).
2. **Giai đoạn 2: Đo điểm chết & Phổ rung động từng Motor (Individual Spin Test)**
   - Kích hoạt tuần tự từng Motor ($M_1 \to M_2 \to M_3 \to M_4$).
   - Rà xung từ 1000us lên đến khi phát hiện rung động vượt ngưỡng nền $\to$ Lưu `PWM_DEADBAND_M1..4`.
   - Chạy các mốc 50%, 80%, 100% công suất trong 1.5 giây để đo biên độ rung cực đại (RMS Accel Noise) $\to$ Tự động tính toán tần số cắt tối ưu cho Bộ lọc số Biquad LPF.
3. **Giai đoạn 3: Chạy thử Full công suất 4 Motor & Bù độ lệch (Dynamic Thrust Balancing)**
   - Đẩy đồng loạt 4 motor từ 10% đến 90-100% công suất (trên giá thử hoặc dây neo an toàn).
   - Bộ tích phân học thích nghi tính toán độ trôi góc và bù hệ số công suất $K_{M1..4}$.
   - **Cơ chế ngắt khẩn cấp**: Nếu góc nghiêng vượt quá $\pm 25^\circ$, lập tức ngắt toàn bộ 4 motor về 1000us trong vòng **1ms**.
4. **Giai đoạn 4: Lưu Flash NVS (Preferences Commit)**
   - Lưu toàn bộ cấu hình `CalibrationProfile` vào bộ nhớ Flash ESP32-S3. Các lần khởi động sau tự động nạp mà không cần căn chỉnh lại.

---

## 4. KIẾN TRÚC ĐA LUỒNG FREERTOS (DUAL-CORE)

- **Core 1 (Thời gian thực - Ưu tiên tối đa 5)**:
  - `Task_FlightControl` (500Hz, chu kỳ 2000us): Đọc I2C 400kHz, lọc Biquad LPF, ước lượng tư thế Madgwick AHRS, tính toán Cascade PID (Góc $\to$ Tốc độ góc), trộn xung Quad-X và băm xung LEDC 4 kênh.
- **Core 0 (Giao tiếp & Định vị - Ưu tiên 1 - 3)**:
  - `Task_GPS` (10Hz): Giải mã NMEA từ NEO-6M qua UART2 bằng TinyGPS++.
  - `Task_Telemetry_WebUI` (20Hz): Phát Wi-Fi SoftAP và truyền WebSocket telemetry thời gian thực.
  - `Task_Blackbox` (50Hz): Ghi dữ liệu cảm biến và góc bay vào bộ đệm tuần hoàn trên chip nhớ ngoài **8MB Octal PSRAM** (`ps_malloc`).

---

## 5. TRẠM ĐIỀU KHIỂN WEB 3D TELEMETRY QUA WI-FI

1. Dùng điện thoại hoặc máy tính kết nối Wi-Fi:
   - **SSID**: `ESP32S3_DRONE_FC`
   - **Mật khẩu**: `12345678`
   - **Địa chỉ IP**: `http://192.168.4.1`
2. Các tính năng trên giao diện:
   - Mô hình 3D trực quan xoay theo góc nghiêng thực tế của Drone (Roll, Pitch, Yaw).
   - Hiển thị tọa độ GPS, số vệ tinh, độ cao, vận tốc, khoảng cách về Home.
   - Nút bấm **"BẮT ĐẦU TỰ CĂN CHỈNH (4 GIAI ĐOẠN)"**.
   - Nút **"NGẮT KHẨN CẤP / DISARM"**.
   - Thanh trượt test từng động cơ.
   - Bảng chỉnh thông số PID Kp, Ki, Kd không cần cắm dây cáp.

---

## 6. HƯỚNG DẪN BIÊN DỊCH VÀ NẠP FIRMWARE

### Biên dịch:
```bash
export PLATFORMIO_SYSTEM_TYPE=linux_aarch64
cd ESP32S3_Quadcopter_FlightController
pio run
```

### Nạp vào bo mạch ESP32-S3 qua USB:
```bash
pio run -t upload
```

### Chạy Unit Test kiểm thử toán học & an toàn:
```bash
./test_runner
```
