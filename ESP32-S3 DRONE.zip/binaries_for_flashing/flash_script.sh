#!/bin/bash
# Script nạp firmware ESP32-S3 Quadcopter qua esptool
# Tự động dò tìm cổng Serial (/dev/ttyUSB* hoặc /dev/ttyACM*)

PORT=${1:-$(ls /dev/ttyUSB* /dev/ttyACM* 2>/dev/null | head -n 1)}

if [ -z "$PORT" ]; then
    echo "[!] Không tìm thấy cổng COM/Serial tự động."
    echo "    Cách dùng: ./flash_script.sh /dev/ttyUSB0 (hoặc /dev/ttyACM0)"
    exit 1
fi

echo "[*] Đang nạp firmware vào ESP32-S3 tại cổng: $PORT..."

python3 -m esptool --chip esp32s3 --port "$PORT" --baud 921600 \
    --before default_reset --after hard_reset write_flash -z \
    --flash_mode dio --flash_freq 80m --flash_size 16MB \
    0x0000 bootloader.bin \
    0x8000 partitions.bin \
    0xe000 boot_app0.bin \
    0x10000 firmware.bin

if [ $? -eq 0 ]; then
    echo "[✓] Nạp firmware thành công 100%!"
    echo "[*] Hãy mở Wi-Fi trên điện thoại, kết nối SSID: 'ESP32S3_DRONE_FC' (Pass: 12345678) và truy cập http://192.168.4.1"
else
    echo "[X] Nạp thất bại. Hãy kiểm tra kết nối cáp USB OTG và giữ nút BOOT khi cắm cáp."
fi
