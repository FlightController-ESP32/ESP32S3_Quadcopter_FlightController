#ifndef AUTO_CALIBRATOR_H
#define AUTO_CALIBRATOR_H

#include <stdint.h>
#include <stdbool.h>
#include <vector>
#include "flight_types.h"
#include "config_pins.h"

// Forward declarations
class MPU6500Driver;
class ESCPWMDriver;

// ============================================================================
// 4-STAGE AUTO-CALIBRATION & DYNAMIC THRUST TRIM ENGINE
// ============================================================================

class AutoCalibrator {
public:
    AutoCalibrator();

    void init(MPU6500Driver* imu = nullptr, ESCPWMDriver* esc = nullptr);

    // Start calibration routine (triggered via WebUI or CLI)
    bool start_calibration();

    // Abort calibration immediately
    void abort_calibration(const char* reason = "Aborted by user");

    // Main tick called in state loop (e.g. 50Hz - 100Hz)
    void tick(uint32_t current_time_ms, const Vector3f& accel_raw, const Vector3f& gyro_raw, const EulerAngles& current_angles);

    // Fast Safety Monitor called in 500Hz loop: Cutoff if tilt > 25 degrees
    bool update_safety_check(float roll_deg, float pitch_deg, float angular_rate_dps);

    // Stage query and progress
    CalibrationStage get_stage() const { return m_stage; }
    uint8_t get_progress_percent() const { return m_progress_percent; }
    const char* get_status_message() const { return m_status_message; }
    bool is_emergency_cutoff_tripped() const { return m_emergency_tripped; }

    const CalibrationProfile& get_profile() const { return m_profile; }
    void set_profile(const CalibrationProfile& profile) { m_profile = profile; }

    // Flash / NVS Save & Load
    bool load_from_nvs();
    bool save_to_nvs();

    // Testing helper
    void force_stage_for_test(CalibrationStage stage) { m_stage = stage; }

private:
    void step_stage_1_static(const Vector3f& accel, const Vector3f& gyro);
    void step_stage_2_individual_spin(uint32_t now_ms, const Vector3f& accel);
    void step_stage_3_dynamic_thrust(uint32_t now_ms, const EulerAngles& angles, const Vector3f& gyro);
    void step_stage_4_commit();

    MPU6500Driver* m_imu;
    ESCPWMDriver*  m_esc;

    CalibrationStage   m_stage;
    uint8_t            m_progress_percent;
    char               m_status_message[128];
    bool               m_emergency_tripped;

    CalibrationProfile m_profile;

    // Stage 1 variables
    uint16_t m_static_sample_count;
    double m_sum_gx, m_sum_gy, m_sum_gz;
    double m_sum_ax, m_sum_ay, m_sum_az;

    // Stage 2 variables
    uint8_t  m_test_motor_idx;      // 0..3
    uint8_t  m_motor_substep;       // 0: Deadband search, 1: 50% power, 2: 80% power, 3: 100% power
    uint16_t m_current_ramp_pwm;
    uint32_t m_step_start_time_ms;
    std::vector<Vector3f> m_vibration_samples;
    float    m_noise_floor_rms;

    // Stage 3 variables
    uint32_t m_thrust_ramp_start_ms;
    float    m_pitch_trim_accum;
    float    m_roll_trim_accum;
};

#endif // AUTO_CALIBRATOR_H
