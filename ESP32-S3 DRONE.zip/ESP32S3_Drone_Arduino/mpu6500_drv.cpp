#include "mpu6500_drv.h"
#include <cstring>
#include <cmath>

#ifdef ARDUINO
#include <Arduino.h>
#include <Wire.h>
#else
#include <iostream>
#endif

// ============================================================================
// BIQUAD LPF IMPLEMENTATION
// ============================================================================
BiquadLPF::BiquadLPF()
    : m_cutoff_hz(60.0f), m_sample_rate_hz(500.0f),
      m_b0(1.0f), m_b1(0.0f), m_b2(0.0f),
      m_a1(0.0f), m_a2(0.0f) {
    reset();
}

void BiquadLPF::init(float cutoff_hz, float sample_rate_hz) {
    m_cutoff_hz = cutoff_hz;
    m_sample_rate_hz = sample_rate_hz;
    compute_coefficients();
    reset();
}

void BiquadLPF::set_cutoff(float cutoff_hz) {
    m_cutoff_hz = cutoff_hz;
    compute_coefficients();
}

void BiquadLPF::reset() {
    for (int i = 0; i < 3; i++) {
        m_x1[i] = m_x2[i] = 0.0f;
        m_y1[i] = m_y2[i] = 0.0f;
    }
}

void BiquadLPF::compute_coefficients() {
    // 2nd Order Butterworth Low-Pass Filter
    // Q = 1 / sqrt(2) approx 0.7071
    if (m_cutoff_hz <= 0.0f || m_sample_rate_hz <= 0.0f) return;

    // Nyquist limit protection
    if (m_cutoff_hz > m_sample_rate_hz * 0.45f) {
        m_cutoff_hz = m_sample_rate_hz * 0.45f;
    }

    const float omega = 2.0f * M_PI * m_cutoff_hz / m_sample_rate_hz;
    const float sn = std::sin(omega);
    const float cs = std::cos(omega);
    const float alpha = sn / (2.0f * 0.70710678f);

    const float a0 = 1.0f + alpha;
    m_b0 = ((1.0f - cs) / 2.0f) / a0;
    m_b1 = (1.0f - cs) / a0;
    m_b2 = ((1.0f - cs) / 2.0f) / a0;
    m_a1 = (-2.0f * cs) / a0;
    m_a2 = (1.0f - alpha) / a0;
}

float BiquadLPF::apply(float sample) {
    float y = m_b0 * sample + m_b1 * m_x1[0] + m_b2 * m_x2[0] - m_a1 * m_y1[0] - m_a2 * m_y2[0];
    m_x2[0] = m_x1[0];
    m_x1[0] = sample;
    m_y2[0] = m_y1[0];
    m_y1[0] = y;
    return y;
}

Vector3f BiquadLPF::apply(const Vector3f& vec) {
    Vector3f out;
    float in_val[3] = { vec.x, vec.y, vec.z };
    float out_val[3];

    for (int i = 0; i < 3; i++) {
        out_val[i] = m_b0 * in_val[i] + m_b1 * m_x1[i] + m_b2 * m_x2[i] - m_a1 * m_y1[i] - m_a2 * m_y2[i];
        m_x2[i] = m_x1[i];
        m_x1[i] = in_val[i];
        m_y2[i] = m_y1[i];
        m_y1[i] = out_val[i];
    }

    out.x = out_val[0];
    out.y = out_val[1];
    out.z = out_val[2];
    return out;
}

// ============================================================================
// MPU6500 DRIVER IMPLEMENTATION
// ============================================================================
MPU6500Driver::MPU6500Driver()
    : m_i2c_addr(MPU6500_I2C_ADDR),
      m_who_am_i(0),
      m_healthy(false) {
    m_accel_bias = Vector3f(0, 0, 0);
    m_gyro_bias  = Vector3f(0, 0, 0);
}

bool MPU6500Driver::init(uint8_t sda_pin, uint8_t scl_pin, uint8_t int_pin) {
#ifdef ARDUINO
    Wire.begin(sda_pin, scl_pin, I2C_MASTER_FREQ_HZ);
    delay(20);

    // Reset device
    write_register(REG_PWR_MGMT_1, 0x80);
    delay(100);

    // Wake up and select Auto-select PLL clock
    write_register(REG_PWR_MGMT_1, 0x01);
    delay(10);

    // Check WHO_AM_I
    uint8_t who = 0;
    if (!read_registers(REG_WHO_AM_I, &who, 1)) {
        Serial.println("[MPU6500] ERROR: Unable to communicate via I2C");
        m_healthy = false;
        return false;
    }
    m_who_am_i = who;
    if (who != MPU6500_WHO_AM_I_VAL && who != MPU6500_WHO_AM_I_ALT) {
        Serial.printf("[MPU6500] WARNING: Unexpected WHO_AM_I: 0x%02X (expected 0x70)\n", who);
    }

    // Set sample rate divider: 1kHz / (1 + 0) = 1kHz
    write_register(REG_SMPLRT_DIV, 0x00);

    // Config DLPF: 184Hz Gyro bandwidth
    write_register(REG_CONFIG, 0x01);

    // Gyro Config: FS_SEL = 1 (+-500 deg/s)
    write_register(REG_GYRO_CONFIG, 0x08);

    // Accel Config: AFS_SEL = 2 (+-8g)
    write_register(REG_ACCEL_CONFIG, 0x10);

    // Accel Config 2: 184Hz Accel DLPF
    write_register(REG_ACCEL_CONFIG2, 0x01);

    // Configure Data Ready Interrupt on INT pin (Active HIGH, Push-Pull, cleared on read)
    write_register(REG_INT_PIN_CFG, 0x10);
    write_register(REG_INT_ENABLE, 0x01); // Raw data ready interrupt

    pinMode(int_pin, INPUT);

    m_healthy = true;
    Serial.println("[MPU6500] Initialization successful @ 400kHz I2C");
#else
    (void)sda_pin; (void)scl_pin; (void)int_pin;
    m_who_am_i = MPU6500_WHO_AM_I_VAL;
    m_healthy = true;
#endif

    // Default filters: 60Hz cutoff at 500Hz sample rate
    m_accel_filter.init(60.0f, 500.0f);
    m_gyro_filter.init(60.0f, 500.0f);

    return m_healthy;
}

bool MPU6500Driver::write_register(uint8_t reg, uint8_t val) {
#ifdef ARDUINO
    Wire.beginTransmission(m_i2c_addr);
    Wire.write(reg);
    Wire.write(val);
    return (Wire.endTransmission() == 0);
#else
    (void)reg; (void)val;
    return true;
#endif
}

bool MPU6500Driver::read_registers(uint8_t reg, uint8_t* buffer, size_t len) {
#ifdef ARDUINO
    Wire.beginTransmission(m_i2c_addr);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) return false;

    size_t count = Wire.requestFrom(m_i2c_addr, (uint8_t)len);
    if (count != len) return false;

    for (size_t i = 0; i < len; i++) {
        buffer[i] = Wire.read();
    }
    return true;
#else
    (void)reg;
    std::memset(buffer, 0, len);
    return true;
#endif
}

bool MPU6500Driver::read_raw(int16_t accel_raw[3], int16_t& temp_raw, int16_t gyro_raw[3]) {
#ifdef ARDUINO
    uint8_t raw[14];
    if (!read_registers(REG_ACCEL_XOUT_H, raw, 14)) {
        return false;
    }

    accel_raw[0] = (int16_t)((raw[0] << 8) | raw[1]);
    accel_raw[1] = (int16_t)((raw[2] << 8) | raw[3]);
    accel_raw[2] = (int16_t)((raw[4] << 8) | raw[5]);

    temp_raw     = (int16_t)((raw[6] << 8) | raw[7]);

    gyro_raw[0]  = (int16_t)((raw[8] << 8) | raw[9]);
    gyro_raw[1]  = (int16_t)((raw[10] << 8) | raw[11]);
    gyro_raw[2]  = (int16_t)((raw[12] << 8) | raw[13]);
    return true;
#else
    accel_raw[0] = 0; accel_raw[1] = 0; accel_raw[2] = 4096; // 1.0g
    temp_raw = 8000;
    gyro_raw[0] = 0; gyro_raw[1] = 0; gyro_raw[2] = 0;
    return true;
#endif
}

bool MPU6500Driver::read_calibrated(Vector3f& accel_g, Vector3f& gyro_dps) {
    int16_t raw_a[3], raw_g[3], raw_t;
    if (!read_raw(raw_a, raw_t, raw_g)) return false;

    // Convert raw to engineering units and apply static zero-point biases
    accel_g.x = (raw_a[0] * ACCEL_SCALE_G) - m_accel_bias.x;
    accel_g.y = (raw_a[1] * ACCEL_SCALE_G) - m_accel_bias.y;
    accel_g.z = (raw_a[2] * ACCEL_SCALE_G) - m_accel_bias.z;

    gyro_dps.x = (raw_g[0] * GYRO_SCALE_DPS) - m_gyro_bias.x;
    gyro_dps.y = (raw_g[1] * GYRO_SCALE_DPS) - m_gyro_bias.y;
    gyro_dps.z = (raw_g[2] * GYRO_SCALE_DPS) - m_gyro_bias.z;

    return true;
}

bool MPU6500Driver::read_filtered(Vector3f& accel_filtered_g, Vector3f& gyro_filtered_dps) {
    Vector3f raw_accel, raw_gyro;
    if (!read_calibrated(raw_accel, raw_gyro)) return false;

    accel_filtered_g = m_accel_filter.apply(raw_accel);
    gyro_filtered_dps = m_gyro_filter.apply(raw_gyro);

    return true;
}

void MPU6500Driver::set_calibration(const CalibrationProfile& profile) {
    m_accel_bias.x = profile.accel_bias[0];
    m_accel_bias.y = profile.accel_bias[1];
    m_accel_bias.z = profile.accel_bias[2];

    m_gyro_bias.x = profile.gyro_bias[0];
    m_gyro_bias.y = profile.gyro_bias[1];
    m_gyro_bias.z = profile.gyro_bias[2];

    if (profile.lpf_cutoff_hz > 10.0f && profile.lpf_cutoff_hz < 200.0f) {
        set_filter_cutoff(profile.lpf_cutoff_hz);
    }
}

void MPU6500Driver::set_filter_cutoff(float cutoff_hz) {
    m_accel_filter.set_cutoff(cutoff_hz);
    m_gyro_filter.set_cutoff(cutoff_hz);
}

void MPU6500Driver::get_biases(Vector3f& accel_bias, Vector3f& gyro_bias) const {
    accel_bias = m_accel_bias;
    gyro_bias = m_gyro_bias;
}

float MPU6500Driver::compute_rms_vibration(const std::vector<Vector3f>& samples) {
    if (samples.empty()) return 0.0f;

    // Calculate mean
    Vector3f mean(0, 0, 0);
    for (const auto& s : samples) {
        mean.x += s.x;
        mean.y += s.y;
        mean.z += s.z;
    }
    const float n = static_cast<float>(samples.size());
    mean.x /= n;
    mean.y /= n;
    mean.z /= n;

    // Calculate variance
    float sum_sq_diff = 0.0f;
    for (const auto& s : samples) {
        float dx = s.x - mean.x;
        float dy = s.y - mean.y;
        float dz = s.z - mean.z;
        sum_sq_diff += (dx * dx + dy * dy + dz * dz);
    }

    return std::sqrt(sum_sq_diff / n);
}
