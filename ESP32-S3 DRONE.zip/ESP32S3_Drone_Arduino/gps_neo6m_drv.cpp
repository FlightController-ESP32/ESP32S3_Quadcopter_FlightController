#include "gps_neo6m_drv.h"
#include <cmath>

#ifdef ARDUINO
#include <Arduino.h>

GPSNeo6MDriver::GPSNeo6MDriver()
    : m_serial(2) {
    m_status.has_fix = false;
    m_status.satellites = 0;
    m_status.latitude = 0.0;
    m_status.longitude = 0.0;
    m_status.altitude_m = 0.0f;
    m_status.speed_kmh = 0.0f;
    m_status.course_deg = 0.0f;
    m_status.home_lat = 0.0;
    m_status.home_lon = 0.0;
    m_status.home_alt = 0.0f;
    m_status.home_locked = false;
}

bool GPSNeo6MDriver::init(uint8_t rx_pin, uint8_t tx_pin, uint32_t baudrate) {
    m_serial.begin(baudrate, SERIAL_8N1, rx_pin, tx_pin);
    Serial.printf("[GPS] Initialized NEO-6M UART2 on RX:%d TX:%d at %d baud\n", rx_pin, tx_pin, baudrate);
    return true;
}

void GPSNeo6MDriver::update() {
    while (m_serial.available() > 0) {
        char c = m_serial.read();
        m_gps.encode(c);
    }

    if (m_gps.location.isUpdated() && m_gps.location.isValid()) {
        m_status.latitude = m_gps.location.lat();
        m_status.longitude = m_gps.location.lng();
        m_status.satellites = m_gps.satellites.isValid() ? m_gps.satellites.value() : 0;
        m_status.altitude_m = m_gps.altitude.isValid() ? m_gps.altitude.meters() : 0.0f;
        m_status.speed_kmh = m_gps.speed.isValid() ? m_gps.speed.kmph() : 0.0f;
        m_status.course_deg = m_gps.course.isValid() ? m_gps.course.deg() : 0.0f;

        // Valid fix requires at least 4 satellites for 3D positioning
        m_status.has_fix = (m_status.satellites >= 4);

        // Auto-lock Home coordinate on initial solid fix
        if (m_status.has_fix && !m_status.home_locked && m_status.satellites >= 6) {
            set_home_location(m_status.latitude, m_status.longitude, m_status.altitude_m);
        }

        if (m_status.home_locked) {
            m_status.distance_to_home_m = get_distance_to_home_m();
            m_status.bearing_to_home_deg = get_bearing_to_home_deg();
        } else {
            m_status.distance_to_home_m = 0.0;
            m_status.bearing_to_home_deg = 0.0;
        }
    }
}

double GPSNeo6MDriver::get_distance_to_home_m() const {
    if (!m_status.home_locked || !m_status.has_fix) return 0.0;
    return TinyGPSPlus::distanceBetween(m_status.latitude, m_status.longitude,
                                        m_status.home_lat, m_status.home_lon);
}

double GPSNeo6MDriver::get_bearing_to_home_deg() const {
    if (!m_status.home_locked || !m_status.has_fix) return 0.0;
    return TinyGPSPlus::courseTo(m_status.latitude, m_status.longitude,
                                 m_status.home_lat, m_status.home_lon);
}

void GPSNeo6MDriver::set_home_location(double lat, double lon, float alt) {
    m_status.home_lat = lat;
    m_status.home_lon = lon;
    m_status.home_alt = alt;
    m_status.home_locked = true;
    Serial.printf("[GPS] Home locked at Lat: %.6f, Lon: %.6f, Alt: %.1fm\n", lat, lon, alt);
}

#else

// Linux native stub for unit tests
GPSNeo6MDriver::GPSNeo6MDriver() {
    m_status.has_fix = false;
    m_status.satellites = 0;
    m_status.latitude = 0.0;
    m_status.longitude = 0.0;
    m_status.altitude_m = 0.0f;
    m_status.speed_kmh = 0.0f;
    m_status.course_deg = 0.0f;
    m_status.home_lat = 0.0;
    m_status.home_lon = 0.0;
    m_status.home_alt = 0.0f;
    m_status.home_locked = false;
}

bool GPSNeo6MDriver::init(uint8_t rx_pin, uint8_t tx_pin, uint32_t baudrate) {
    (void)rx_pin; (void)tx_pin; (void)baudrate;
    return true;
}

void GPSNeo6MDriver::update() {}

double GPSNeo6MDriver::get_distance_to_home_m() const { return 0.0; }
double GPSNeo6MDriver::get_bearing_to_home_deg() const { return 0.0; }

void GPSNeo6MDriver::set_home_location(double lat, double lon, float alt) {
    m_status.home_lat = lat;
    m_status.home_lon = lon;
    m_status.home_alt = alt;
    m_status.home_locked = true;
}

#endif
