#ifndef PID_MIXER_H
#define PID_MIXER_H

#include <stdint.h>
#include <stdbool.h>
#include <algorithm>
#include "flight_types.h"
#include "config_pins.h"

// ============================================================================
// SINGLE AXIS PID CONTROLLER WITH ANTI-WINDUP
// ============================================================================
class PIDController {
public:
    PIDController();
    PIDController(const PIDConfig& config);

    void set_config(const PIDConfig& config);
    PIDConfig get_config() const { return m_config; }

    void reset();
    float update(float setpoint, float measurement, float dt);

private:
    PIDConfig m_config;
    float m_integral;
    float m_last_measurement;
    bool m_first_run;
};

// ============================================================================
// DUAL-LOOP CASCADE PID CONTROLLER (ANGLE -> RATE)
// ============================================================================
class CascadePIDController {
public:
    CascadePIDController();
    CascadePIDController(const PIDConfig& angle_config, const PIDConfig& rate_config);

    void set_configs(const PIDConfig& angle_config, const PIDConfig& rate_config);
    void reset();

    // Cascaded compute: Target Angle -> Target Rate -> Output Torque
    float update(float target_angle, float current_angle, float current_rate, float dt);

    // Direct Rate compute (Acro mode): Target Rate -> Output Torque
    float update_rate(float target_rate, float current_rate, float dt);

    PIDController& get_angle_pid() { return m_angle_pid; }
    PIDController& get_rate_pid() { return m_rate_pid; }

private:
    PIDController m_angle_pid;
    PIDController m_rate_pid;
};

// ============================================================================
// QUAD-X MOTOR MIXER WITH DYNAMIC TRIM & DEADBAND SCALING
// ============================================================================
class QuadXMixer {
public:
    QuadXMixer();

    void set_calibration_profile(const CalibrationProfile& profile);
    const CalibrationProfile& get_calibration_profile() const { return m_profile; }

    // Compute 4 motor PWMs (us) from throttle and 3-axis PID outputs
    void compute(uint16_t throttle_command,
                 float roll_pid,
                 float pitch_pid,
                 float yaw_pid,
                 bool is_armed,
                 uint16_t out_motor_pwms[4]);

    // 3-Motor Fault-Tolerant Controlled Spin Descent
    // When 1 of 4 motors fails, balances remaining 3 motors to descend safely without flipping
    void compute_3motor_emergency(uint16_t descent_throttle,
                                  int8_t failed_motor_idx,
                                  float roll_gyro_dps,
                                  float pitch_gyro_dps,
                                  uint16_t out_motor_pwms[4]);

    // Detects if a motor has disconnected or lost thrust completely
    int8_t detect_motor_failure(const uint16_t commanded_pwms[4],
                                float roll_rate_dps,
                                float pitch_rate_dps,
                                float dt);

    void reset_fault_detector();

private:
    CalibrationProfile m_profile;
    float m_fault_accum[4]; // Accumulator for desync detection
};

#endif // PID_MIXER_H
