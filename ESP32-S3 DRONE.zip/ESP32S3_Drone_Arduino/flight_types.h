#ifndef FLIGHT_TYPES_H
#define FLIGHT_TYPES_H

#include <stdint.h>
#include <stdbool.h>
#include <cstddef>

// ============================================================================
// COMMON FLIGHT DATA STRUCTURES & TYPES
// ============================================================================

struct Vector3f {
    float x;
    float y;
    float z;

    Vector3f() : x(0.0f), y(0.0f), z(0.0f) {}
    Vector3f(float _x, float _y, float _z) : x(_x), y(_y), z(_z) {}
};

struct Quaternion4f {
    float q0; // w
    float q1; // x
    float q2; // y
    float q3; // z

    Quaternion4f() : q0(1.0f), q1(0.0f), q2(0.0f), q3(0.0f) {}
    Quaternion4f(float _q0, float _q1, float _q2, float _q3) : q0(_q0), q1(_q1), q2(_q2), q3(_q3) {}
};

struct EulerAngles {
    float roll;   // degrees (-180 to +180)
    float pitch;  // degrees (-90 to +90)
    float yaw;    // degrees (0 to 360 or -180 to +180)

    EulerAngles() : roll(0.0f), pitch(0.0f), yaw(0.0f) {}
    EulerAngles(float r, float p, float y) : roll(r), pitch(p), yaw(y) {}
};

// ----------------------------------------------------------------------------
// Calibration Profile (Stored in ESP32 Flash / NVS Preferences)
// ----------------------------------------------------------------------------
#define CALIBRATION_MAGIC 0x44524F4E // 'DRON'

struct CalibrationProfile {
    uint32_t magic;
    bool is_valid;

    // IMU Zero-point offsets
    float gyro_bias[3];   // X, Y, Z in deg/s
    float accel_bias[3];  // X, Y, Z in g

    // ESC Starting Deadband (us) - Range typically 1000us - 1180us
    uint16_t esc_deadband[4];

    // Dynamic Thrust Trimming Factor K_Mi in [0.85, 1.15], default 1.0
    float motor_thrust_trim[4];

    // Adaptive Low Pass Filter Cutoff Frequency (Hz)
    float lpf_cutoff_hz;

    // Vibration Peak RMS Noise (g) recorded during max spin test
    float peak_vibration_rms[4];

    uint32_t checksum;

    void reset_to_defaults() {
        magic = CALIBRATION_MAGIC;
        is_valid = false;
        gyro_bias[0] = gyro_bias[1] = gyro_bias[2] = 0.0f;
        accel_bias[0] = accel_bias[1] = 0.0f;
        accel_bias[2] = 0.0f; // Gravity offset handled in filter
        for (int i = 0; i < 4; i++) {
            esc_deadband[i] = 1050;       // Standard default deadband
            motor_thrust_trim[i] = 1.0f;  // Balanced default
            peak_vibration_rms[i] = 0.0f;
        }
        lpf_cutoff_hz = 60.0f;           // Default 60Hz cutoff
        checksum = 0;
    }

    uint32_t calculate_checksum() const {
        uint32_t sum = magic;
        const uint8_t* p = reinterpret_cast<const uint8_t*>(this);
        size_t len = sizeof(CalibrationProfile) - sizeof(uint32_t);
        for (size_t i = 0; i < len; i++) {
            sum = (sum * 31) + p[i];
        }
        return sum;
    }
};

// ----------------------------------------------------------------------------
// Cascade PID Controller Structures
// ----------------------------------------------------------------------------
struct PIDConfig {
    float kp;
    float ki;
    float kd;
    float i_max;
    float out_max;

    PIDConfig() : kp(0.0f), ki(0.0f), kd(0.0f), i_max(0.0f), out_max(0.0f) {}
    PIDConfig(float p, float i, float d, float imax, float omax)
        : kp(p), ki(i), kd(d), i_max(imax), out_max(omax) {}
};

enum FlightMode : uint8_t {
    MODE_DISARMED = 0,
    MODE_CALIBRATING,
    MODE_ACRO_RATE,
    MODE_STABILIZE_ANGLE,
    MODE_ALT_HOLD,
    MODE_RETURN_TO_HOME,
    MODE_FAILSAFE_LAND,
    MODE_MOTOR_FAIL_DESCENT, // 3-Motor Emergency Controlled Descent
    MODE_EMERGENCY_STOP
};

enum CalibrationStage : uint8_t {
    CALIB_STAGE_IDLE = 0,
    CALIB_STAGE_1_STATIC_ZERO,       // 2000 samples level IMU offset
    CALIB_STAGE_2_SPIN_VIBRATION,    // Step-through M1..M4 deadband & RMS noise
    CALIB_STAGE_3_FULL_POWER_THRUST, // Ramp all 4 to capped 50-60% on tether/rig
    CALIB_STAGE_4_NVS_COMMIT,        // Save to NVS
    CALIB_STAGE_COMPLETE,
    CALIB_STAGE_FAILED
};

enum FailsafeReason : uint8_t {
    FAILSAFE_REASON_NONE = 0,
    FAILSAFE_REASON_LOST_SIGNAL,      // Wi-Fi or Web RC signal lost > 2.0s
    FAILSAFE_REASON_LOW_BATTERY,      // LiPo 2S voltage < critical threshold (6.6V)
    FAILSAFE_REASON_MOTOR_FAILURE,    // 1 of 4 motors failed / desynced
    FAILSAFE_REASON_CRITICAL_TILT     // Tilt > 45 deg during flight
};

enum RTHPhase : uint8_t {
    RTH_PHASE_IDLE = 0,
    RTH_PHASE_ROTATE_TO_HOME,         // Align yaw heading to home waypoint
    RTH_PHASE_FLY_HOME,               // Fly towards home waypoint coordinates
    RTH_PHASE_DESCEND_LAND,           // Soft landing descent above home
    RTH_PHASE_DISARM_DONE             // Landed and disarmed
};

// ----------------------------------------------------------------------------
// RC Virtual Joystick Command (Mode 2)
// ----------------------------------------------------------------------------
struct RCCommand {
    uint16_t throttle_us;    // 1000..2000 us (Left Stick Vertical)
    float    yaw_rate_dps;   // -150..+150 deg/s (Left Stick Horizontal)
    float    pitch_deg;      // -25..+25 deg (Right Stick Vertical: + is pitch nose DOWN/advance)
    float    roll_deg;       // -25..+25 deg (Right Stick Horizontal: + is roll RIGHT)
    bool     armed;
    bool     rth_requested;
    uint32_t timestamp_ms;

    RCCommand()
        : throttle_us(1000), yaw_rate_dps(0.0f), pitch_deg(0.0f), roll_deg(0.0f),
          armed(false), rth_requested(false), timestamp_ms(0) {}
};

// ----------------------------------------------------------------------------
// Battery Status
// ----------------------------------------------------------------------------
struct BatteryStatus {
    float voltage_v;
    float cell_v;
    bool  is_warning;    // < 7.0V (3.5V/cell)
    bool  is_critical;   // < 6.6V (3.3V/cell) -> Triggers RTH / Emergency Land
    uint8_t percentage;

    BatteryStatus()
        : voltage_v(7.4f), cell_v(3.7f), is_warning(false), is_critical(false), percentage(100) {}
};

// ----------------------------------------------------------------------------
// Motor Fault Detection & Health Status
// ----------------------------------------------------------------------------
struct MotorHealthStatus {
    bool has_failed_motor;
    int8_t failed_motor_idx; // -1 if all OK, 0..3 for M1..M4
    float desync_time_ms[4];

    MotorHealthStatus()
        : has_failed_motor(false), failed_motor_idx(-1) {
        for (int i = 0; i < 4; i++) desync_time_ms[i] = 0.0f;
    }
};

// ----------------------------------------------------------------------------
// Telemetry & GPS Data
// ----------------------------------------------------------------------------
struct GPSStatus {
    bool has_fix;
    uint8_t satellites;
    double latitude;
    double longitude;
    float altitude_m;
    float speed_kmh;
    float course_deg;
    double home_lat;
    double home_lon;
    float home_alt;
    bool home_locked;
    double distance_to_home_m;
    double bearing_to_home_deg;
};

// ----------------------------------------------------------------------------
// PSRAM Blackbox Record (Aligned to 32 bytes for fast DMA/memory access)
// ----------------------------------------------------------------------------
struct __attribute__((packed)) BlackboxRecord {
    uint32_t timestamp_us;
    int16_t roll_cdeg;       // Centi-degrees (e.g. 15.25 deg = 1525)
    int16_t pitch_cdeg;
    int16_t yaw_cdeg;
    int16_t gyro_raw[3];     // Raw gyro X, Y, Z
    int16_t accel_raw[3];    // Raw accel X, Y, Z
    uint16_t motor_pwm[4];   // 1000 - 2000 us
    uint8_t flight_mode;
    uint8_t flags;
};

#endif // FLIGHT_TYPES_H
