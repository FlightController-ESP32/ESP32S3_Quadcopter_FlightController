#include "esc_pwm_drv.h"
#include <algorithm>

#ifdef ARDUINO
#include <Arduino.h>
#include <driver/ledc.h>
#else
#include <iostream>
#endif

const uint8_t ESCPWMDriver::MOTOR_PINS[4] = {
    ESC_M1_PIN, // GPIO 4
    ESC_M2_PIN, // GPIO 5
    ESC_M3_PIN, // GPIO 6
    ESC_M4_PIN  // GPIO 7
};

const uint8_t ESCPWMDriver::LEDC_CHANNELS[4] = { 0, 1, 2, 3 };

ESCPWMDriver::ESCPWMDriver()
    : m_armed(false), m_initialized(false) {
    for (int i = 0; i < 4; i++) {
        m_current_pwms[i] = ESC_MIN_PULSE_US;
    }
}

uint32_t ESCPWMDriver::us_to_duty(uint16_t pulse_us) const {
    // Clamping to valid range
    uint16_t clamped_us = std::max<uint16_t>(ESC_MIN_PULSE_US, std::min<uint16_t>(ESC_MAX_PULSE_US, pulse_us));

    // Frequency = 400Hz -> Period = 2500us
    // Resolution = 14-bit -> 2^14 = 16384 ticks per period
    // duty = (pulse_us / 2500.0) * 16384
    return (static_cast<uint32_t>(clamped_us) * (1UL << ESC_PWM_RESOLUTION)) / 2500UL;
}

bool ESCPWMDriver::init() {
#ifdef ARDUINO
    // Configure LEDC Timer
    ledc_timer_config_t ledc_timer = {
        .speed_mode       = LEDC_LOW_SPEED_MODE,
        .duty_resolution  = static_cast<ledc_timer_bit_t>(ESC_PWM_RESOLUTION),
        .timer_num        = LEDC_TIMER_0,
        .freq_hz          = ESC_PWM_FREQ_HZ,
        .clk_cfg          = LEDC_AUTO_CLK
    };
    esp_err_t err = ledc_timer_config(&ledc_timer);
    if (err != ESP_OK) {
        Serial.printf("[ESC_PWM] Failed to configure LEDC timer: %d\n", err);
        return false;
    }

    // Configure 4 LEDC Channels
    for (int i = 0; i < 4; i++) {
        ledc_channel_config_t ledc_channel = {
            .gpio_num       = MOTOR_PINS[i],
            .speed_mode     = LEDC_LOW_SPEED_MODE,
            .channel        = static_cast<ledc_channel_t>(LEDC_CHANNELS[i]),
            .intr_type      = LEDC_INTR_DISABLE,
            .timer_sel      = LEDC_TIMER_0,
            .duty           = us_to_duty(ESC_MIN_PULSE_US),
            .hpoint         = 0,
            .flags          = { .output_invert = 0 }
        };
        err = ledc_channel_config(&ledc_channel);
        if (err != ESP_OK) {
            Serial.printf("[ESC_PWM] Failed to configure LEDC channel %d: %d\n", i, err);
            return false;
        }
    }

    Serial.println("[ESC_PWM] 4-Channel LEDC initialized at 400Hz (GPIO 4, 5, 6, 7)");
#endif

    m_initialized = true;
    m_armed = false;
    emergency_stop();
    return true;
}

void ESCPWMDriver::write_motor_us(uint8_t motor_idx, uint16_t pulse_us) {
    if (motor_idx >= 4) return;

    if (!m_armed) {
        pulse_us = ESC_MIN_PULSE_US;
    } else {
        pulse_us = std::max<uint16_t>(ESC_MIN_PULSE_US, std::min<uint16_t>(ESC_MAX_PULSE_US, pulse_us));
    }

    m_current_pwms[motor_idx] = pulse_us;

#ifdef ARDUINO
    uint32_t duty = us_to_duty(pulse_us);
    ledc_set_duty(LEDC_LOW_SPEED_MODE, static_cast<ledc_channel_t>(LEDC_CHANNELS[motor_idx]), duty);
    ledc_update_duty(LEDC_LOW_SPEED_MODE, static_cast<ledc_channel_t>(LEDC_CHANNELS[motor_idx]));
#endif
}

void ESCPWMDriver::write_all_us(const uint16_t motor_pwms[4]) {
    for (int i = 0; i < 4; i++) {
        write_motor_us(i, motor_pwms[i]);
    }
}

void ESCPWMDriver::get_current_pwms(uint16_t motor_pwms[4]) const {
    for (int i = 0; i < 4; i++) {
        motor_pwms[i] = m_current_pwms[i];
    }
}

void ESCPWMDriver::emergency_stop() {
    m_armed = false;
    for (int i = 0; i < 4; i++) {
        m_current_pwms[i] = ESC_MIN_PULSE_US;
#ifdef ARDUINO
        uint32_t duty = us_to_duty(ESC_MIN_PULSE_US);
        ledc_set_duty(LEDC_LOW_SPEED_MODE, static_cast<ledc_channel_t>(LEDC_CHANNELS[i]), duty);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, static_cast<ledc_channel_t>(LEDC_CHANNELS[i]));
#endif
    }
}

void ESCPWMDriver::set_armed(bool armed) {
    m_armed = armed;
    if (!m_armed) {
        emergency_stop();
    }
}

void ESCPWMDriver::run_endpoint_calibration() {
#ifdef ARDUINO
    Serial.println("[ESC_PWM] Starting ESC Endpoint Calibration...");
    Serial.println("[ESC_PWM] Sending 2000us max throttle signal. Power ON battery now!");
    
    // Output 2000us to all 4 motors
    for (int i = 0; i < 4; i++) {
        uint32_t duty = us_to_duty(ESC_MAX_PULSE_US);
        ledc_set_duty(LEDC_LOW_SPEED_MODE, static_cast<ledc_channel_t>(LEDC_CHANNELS[i]), duty);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, static_cast<ledc_channel_t>(LEDC_CHANNELS[i]));
    }
    delay(4000); // Wait for ESC power-up beeps

    Serial.println("[ESC_PWM] Sending 1000us min throttle signal...");
    // Output 1000us
    for (int i = 0; i < 4; i++) {
        uint32_t duty = us_to_duty(ESC_MIN_PULSE_US);
        ledc_set_duty(LEDC_LOW_SPEED_MODE, static_cast<ledc_channel_t>(LEDC_CHANNELS[i]), duty);
        ledc_update_duty(LEDC_LOW_SPEED_MODE, static_cast<ledc_channel_t>(LEDC_CHANNELS[i]));
    }
    delay(3000); // Wait for confirmation beeps

    Serial.println("[ESC_PWM] ESC Endpoint Calibration Completed successfully!");
#endif
}
