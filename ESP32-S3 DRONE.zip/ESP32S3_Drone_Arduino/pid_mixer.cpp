#include "pid_mixer.h"
#include <cmath>

// ============================================================================
// SINGLE AXIS PID CONTROLLER
// ============================================================================
PIDController::PIDController()
    : m_config(0, 0, 0, 0, 0),
      m_integral(0.0f),
      m_last_measurement(0.0f),
      m_first_run(true) {
}

PIDController::PIDController(const PIDConfig& config)
    : m_config(config),
      m_integral(0.0f),
      m_last_measurement(0.0f),
      m_first_run(true) {
}

void PIDController::set_config(const PIDConfig& config) {
    m_config = config;
}

void PIDController::reset() {
    m_integral = 0.0f;
    m_last_measurement = 0.0f;
    m_first_run = true;
}

float PIDController::update(float setpoint, float measurement, float dt) {
    if (dt <= 0.0f) return 0.0f;

    float error = setpoint - measurement;

    // Proportional term
    float p_out = m_config.kp * error;

    // Integral term with Anti-Windup
    m_integral += m_config.ki * error * dt;
    if (m_config.i_max > 0.0f) {
        m_integral = std::max(-m_config.i_max, std::min(m_config.i_max, m_integral));
    }

    // Derivative on measurement to prevent derivative kick
    float d_out = 0.0f;
    if (!m_first_run) {
        float derivative = (measurement - m_last_measurement) / dt;
        d_out = -m_config.kd * derivative;
    } else {
        m_first_run = false;
    }
    m_last_measurement = measurement;

    // Total output
    float total = p_out + m_integral + d_out;
    if (m_config.out_max > 0.0f) {
        total = std::max(-m_config.out_max, std::min(m_config.out_max, total));
    }

    return total;
}

// ============================================================================
// CASCADE PID CONTROLLER
// ============================================================================
CascadePIDController::CascadePIDController()
    : m_angle_pid(), m_rate_pid() {
}

CascadePIDController::CascadePIDController(const PIDConfig& angle_config, const PIDConfig& rate_config)
    : m_angle_pid(angle_config), m_rate_pid(rate_config) {
}

void CascadePIDController::set_configs(const PIDConfig& angle_config, const PIDConfig& rate_config) {
    m_angle_pid.set_config(angle_config);
    m_rate_pid.set_config(rate_config);
}

void CascadePIDController::reset() {
    m_angle_pid.reset();
    m_rate_pid.reset();
}

float CascadePIDController::update(float target_angle, float current_angle, float current_rate, float dt) {
    // Outer Angle Loop produces target angular rate (deg/s)
    float target_rate = m_angle_pid.update(target_angle, current_angle, dt);

    // Inner Rate Loop produces motor torque request
    return m_rate_pid.update(target_rate, current_rate, dt);
}

float CascadePIDController::update_rate(float target_rate, float current_rate, float dt) {
    return m_rate_pid.update(target_rate, current_rate, dt);
}

// ============================================================================
// QUAD-X MOTOR MIXER
// ============================================================================
QuadXMixer::QuadXMixer() {
    m_profile.reset_to_defaults();
    reset_fault_detector();
}

void QuadXMixer::reset_fault_detector() {
    for (int i = 0; i < 4; i++) {
        m_fault_accum[i] = 0.0f;
    }
}

void QuadXMixer::set_calibration_profile(const CalibrationProfile& profile) {
    m_profile = profile;
}

void QuadXMixer::compute(uint16_t throttle_command,
                         float roll_pid,
                         float pitch_pid,
                         float yaw_pid,
                         bool is_armed,
                         uint16_t out_motor_pwms[4]) {
    if (!is_armed || throttle_command == 0) {
        for (int i = 0; i < 4; i++) {
            out_motor_pwms[i] = ESC_MIN_PULSE_US;
        }
        return;
    }

    // Quad-X Mixing Matrix according to README.pdf Section 3.1:
    // Motor 1 (Front-Left, CW, GPIO 4):    Throttle + Pitch - Roll - Yaw
    // Motor 2 (Front-Right, CCW, GPIO 5):   Throttle + Pitch + Roll + Yaw
    // Motor 3 (Rear-Right, CW, GPIO 6):    Throttle - Pitch + Roll - Yaw
    // Motor 4 (Rear-Left, CCW, GPIO 7):   Throttle - Pitch - Roll + Yaw
    float mix[4];
    mix[0] = static_cast<float>(throttle_command) + pitch_pid - roll_pid - yaw_pid;
    mix[1] = static_cast<float>(throttle_command) + pitch_pid + roll_pid + yaw_pid;
    mix[2] = static_cast<float>(throttle_command) - pitch_pid + roll_pid - yaw_pid;
    mix[3] = static_cast<float>(throttle_command) - pitch_pid - roll_pid + yaw_pid;

    for (int i = 0; i < 4; i++) {
        // Enforce K_Mi factor in [0.85, 1.15]
        float k_trim = m_profile.motor_thrust_trim[i];
        if (k_trim < 0.85f) k_trim = 0.85f;
        if (k_trim > 1.15f) k_trim = 1.15f;

        // Base deadband offset
        uint16_t deadband = m_profile.esc_deadband[i];
        if (deadband < ESC_MIN_PULSE_US) deadband = ESC_MIN_PULSE_US;
        if (deadband > 1200) deadband = 1200;

        // Formula: PWM_i = PWM_deadband_i + K_Mi * (Mixer_i)
        float pwm = static_cast<float>(deadband) + k_trim * mix[i];

        // Clamp to valid ESC output range [1000, 2000] us
        if (pwm < static_cast<float>(ESC_MIN_PULSE_US)) {
            pwm = static_cast<float>(ESC_MIN_PULSE_US);
        } else if (pwm > static_cast<float>(ESC_MAX_PULSE_US)) {
            pwm = static_cast<float>(ESC_MAX_PULSE_US);
        }

        out_motor_pwms[i] = static_cast<uint16_t>(std::round(pwm));
    }
}

int8_t QuadXMixer::detect_motor_failure(const uint16_t commanded_pwms[4],
                                       float roll_rate_dps,
                                       float pitch_rate_dps,
                                       float dt) {
    if (dt <= 0.0f) return -1;

    // Check each motor: if a motor is commanded high (>1450us)
    // but the aircraft is accelerating negatively on that motor's arm for > 0.20s
    // M1: Front-Left  -> should induce +pitch, -roll (nose down, right wing down)
    // If dead, vehicle rolls left (-roll_rate) and pitches up (+pitch_rate)
    bool symptom[4] = {
        (commanded_pwms[0] > 1450) && (roll_rate_dps < -35.0f && pitch_rate_dps > 35.0f),  // M1 failed
        (commanded_pwms[1] > 1450) && (roll_rate_dps > 35.0f && pitch_rate_dps > 35.0f),   // M2 failed
        (commanded_pwms[2] > 1450) && (roll_rate_dps > 35.0f && pitch_rate_dps < -35.0f),  // M3 failed
        (commanded_pwms[3] > 1450) && (roll_rate_dps < -35.0f && pitch_rate_dps < -35.0f)   // M4 failed
    };

    for (int i = 0; i < 4; i++) {
        if (symptom[i]) {
            m_fault_accum[i] += dt;
            if (m_fault_accum[i] > 0.20f) { // 200ms of sustained desync
                return static_cast<int8_t>(i);
            }
        } else {
            m_fault_accum[i] = std::max(0.0f, m_fault_accum[i] - dt * 2.0f);
        }
    }
    return -1;
}

void QuadXMixer::compute_3motor_emergency(uint16_t descent_throttle,
                                          int8_t failed_motor_idx,
                                          float roll_gyro_dps,
                                          float pitch_gyro_dps,
                                          uint16_t out_motor_pwms[4]) {
    // Controlled Spin Descent:
    // Quadcopter sacrifices yaw stabilization to stay upright while spinning rapidly like a samara seed.
    // 1. Turn off dead motor completely
    // 2. Reduce opposite motor to avoid flipping towards the dead corner
    // 3. Drive the adjacent pair at sufficient thrust to cushion descent
    if (failed_motor_idx < 0 || failed_motor_idx >= 4) {
        for (int i = 0; i < 4; i++) out_motor_pwms[i] = descent_throttle;
        return;
    }

    uint8_t opposite_idx = (failed_motor_idx + 2) % 4;
    uint8_t adj1_idx     = (failed_motor_idx + 1) % 4;
    uint8_t adj2_idx     = (failed_motor_idx + 3) % 4;

    // Gyro damping to keep spin disk flat
    float roll_damping  = -0.4f * roll_gyro_dps;
    float pitch_damping = -0.4f * pitch_gyro_dps;

    // Dead motor: shut down
    out_motor_pwms[failed_motor_idx] = ESC_MIN_PULSE_US;

    // Opposite motor: reduced to ~25% power to counterbalance the missing motor's moment
    float opp_pwm = static_cast<float>(ESC_MIN_PULSE_US) + 0.25f * static_cast<float>(descent_throttle - ESC_MIN_PULSE_US);
    out_motor_pwms[opposite_idx] = static_cast<uint16_t>(std::max(1000.0f, std::min(1300.0f, opp_pwm)));

    // Adjacent pair: carries the vehicle in stable spin
    float adj1_pwm = static_cast<float>(descent_throttle) + roll_damping + pitch_damping;
    float adj2_pwm = static_cast<float>(descent_throttle) - roll_damping - pitch_damping;

    out_motor_pwms[adj1_idx] = static_cast<uint16_t>(std::max(1050.0f, std::min(1650.0f, adj1_pwm)));
    out_motor_pwms[adj2_idx] = static_cast<uint16_t>(std::max(1050.0f, std::min(1650.0f, adj2_pwm)));
}
