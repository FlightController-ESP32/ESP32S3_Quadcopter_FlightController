#ifndef AHRS_MADGWICK_H
#define AHRS_MADGWICK_H

#include <stdint.h>
#include <cmath>
#include "flight_types.h"

// ============================================================================
// MADGWICK AHRS SENSOR FUSION ALGORITHM
// ============================================================================

class MadgwickAHRS {
public:
    MadgwickAHRS();

    void init(float sample_freq_hz = 500.0f, float beta = 0.1f);
    void reset();

    // Update with 6-DOF IMU (Gyro: deg/s, Accel: g)
    void update(float gx_dps, float gy_dps, float gz_dps,
                float ax_g, float ay_g, float az_g);

    // Update with dt (seconds)
    void update_dt(float gx_dps, float gy_dps, float gz_dps,
                   float ax_g, float ay_g, float az_g, float dt);

    EulerAngles get_euler_angles() const;
    Quaternion4f get_quaternion() const { return Quaternion4f(m_q0, m_q1, m_q2, m_q3); }

    void set_beta(float beta) { m_beta = beta; }
    float get_beta() const { return m_beta; }

private:
    static float inv_sqrt(float x);

    float m_sample_freq_hz;
    float m_inv_sample_freq;
    float m_beta; // Algorithm gain

    // Quaternions
    float m_q0, m_q1, m_q2, m_q3;
};

#endif // AHRS_MADGWICK_H
