#ifndef CONFIG_PINS_H
#define CONFIG_PINS_H

#include <stdint.h>

// ============================================================================
// ESP32-S3 N16R8 QUADCOPTER PIN CONFIGURATION & HARDWARE GUARDS
// ============================================================================

// ----------------------------------------------------------------------------
// 1. Cảm biến MPU6500 (GY-6500) - I2C0 Bus
// AD0 nối GND -> Địa chỉ I2C = 0x68
// ----------------------------------------------------------------------------
#define IMU_SDA_PIN         8       // GPIO 8 -> SDA của MPU6500
#define IMU_SCL_PIN         9       // GPIO 9 -> SCL của MPU6500
#define IMU_INT_PIN         10      // GPIO 10 -> INT của MPU6500 (Data Ready Interrupt)
#define MPU6500_I2C_ADDR    0x68    // AD0 tied to GND
#define I2C_MASTER_FREQ_HZ  400000  // 400kHz Fast Mode

// ----------------------------------------------------------------------------
// 2. Module Định Vị GPS NEO-6M - UART2 (Cross TX/RX)
// ----------------------------------------------------------------------------
#define GPS_RX_PIN          18      // GPIO 18 (RX2) <- Nối vào chân TXD của NEO-6M
#define GPS_TX_PIN          17      // GPIO 17 (TX2) -> Nối vào chân RXD của NEO-6M
#define GPS_BAUDRATE        9600    // Baudrate mặc định của NEO-6M

// ----------------------------------------------------------------------------
// 3. Khối Động Lực: 4 ESC & Motor 2100KV (Quad-X Layout)
// Dây đỏ 5V BEC ở giữa của cả 4 giắc ESC ĐÃ CẮT BỎ (NC)
// ----------------------------------------------------------------------------
#define ESC_M1_PIN          4       // GPIO 4 -> SIG ESC 1 (Motor 1: Trước - Trái, CW)
#define ESC_M2_PIN          5       // GPIO 5 -> SIG ESC 2 (Motor 2: Trước - Phải, CCW)
#define ESC_M3_PIN          6       // GPIO 6 -> SIG ESC 3 (Motor 3: Sau - Phải, CW)
#define ESC_M4_PIN          7       // GPIO 7 -> SIG ESC 4 (Motor 4: Sau - Trái, CCW)

// Tần số & độ phân giải xung PWM điều tốc
#define ESC_PWM_FREQ_HZ     400     // 400Hz (chu kỳ 2500us)
#define ESC_PWM_RESOLUTION  14      // 14-bit resolution (0..16383)
#define ESC_MIN_PULSE_US    1000    // 1000us (Ngắt ga / Idle)
#define ESC_MAX_PULSE_US    2000    // 2000us (Max 100% công suất)

// ----------------------------------------------------------------------------
// RÀNG BUỘC PHẦN CỨNG BẮT BUỘC TRÊN ESP32-S3 N16R8:
// TUYỆT ĐỐI KHÔNG SỬ DỤNG GPIO 35, 36, 37 (OCTAL PSRAM 8MB INTERNAL CONNECTIONS)
// ----------------------------------------------------------------------------
static_assert(IMU_SDA_PIN != 35 && IMU_SDA_PIN != 36 && IMU_SDA_PIN != 37, "GPIO conflict with Octal PSRAM");
static_assert(IMU_SCL_PIN != 35 && IMU_SCL_PIN != 36 && IMU_SCL_PIN != 37, "GPIO conflict with Octal PSRAM");
static_assert(IMU_INT_PIN != 35 && IMU_INT_PIN != 36 && IMU_INT_PIN != 37, "GPIO conflict with Octal PSRAM");
static_assert(GPS_RX_PIN != 35 && GPS_RX_PIN != 36 && GPS_RX_PIN != 37, "GPIO conflict with Octal PSRAM");
static_assert(GPS_TX_PIN != 35 && GPS_TX_PIN != 36 && GPS_TX_PIN != 37, "GPIO conflict with Octal PSRAM");
static_assert(ESC_M1_PIN != 35 && ESC_M1_PIN != 36 && ESC_M1_PIN != 37, "GPIO conflict with Octal PSRAM");
static_assert(ESC_M2_PIN != 35 && ESC_M2_PIN != 36 && ESC_M2_PIN != 37, "GPIO conflict with Octal PSRAM");
static_assert(ESC_M3_PIN != 35 && ESC_M3_PIN != 36 && ESC_M3_PIN != 37, "GPIO conflict with Octal PSRAM");
static_assert(ESC_M4_PIN != 35 && ESC_M4_PIN != 36 && ESC_M4_PIN != 37, "GPIO conflict with Octal PSRAM");

#endif // CONFIG_PINS_H
