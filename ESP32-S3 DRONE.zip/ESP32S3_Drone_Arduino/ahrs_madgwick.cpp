#include "ahrs_madgwick.h"

MadgwickAHRS::MadgwickAHRS()
    : m_sample_freq_hz(500.0f),
      m_inv_sample_freq(1.0f / 500.0f),
      m_beta(0.1f),
      m_q0(1.0f), m_q1(0.0f), m_q2(0.0f), m_q3(0.0f) {
}

void MadgwickAHRS::init(float sample_freq_hz, float beta) {
    m_sample_freq_hz = sample_freq_hz;
    m_inv_sample_freq = 1.0f / sample_freq_hz;
    m_beta = beta;
    reset();
}

void MadgwickAHRS::reset() {
    m_q0 = 1.0f;
    m_q1 = 0.0f;
    m_q2 = 0.0f;
    m_q3 = 0.0f;
}

float MadgwickAHRS::inv_sqrt(float x) {
    if (x <= 0.0f) return 0.0f;
    return 1.0f / std::sqrt(x);
}

void MadgwickAHRS::update(float gx_dps, float gy_dps, float gz_dps,
                          float ax_g, float ay_g, float az_g) {
    update_dt(gx_dps, gy_dps, gz_dps, ax_g, ay_g, az_g, m_inv_sample_freq);
}

void MadgwickAHRS::update_dt(float gx_dps, float gy_dps, float gz_dps,
                             float ax_g, float ay_g, float az_g, float dt) {
    // Convert gyro from degrees/s to radians/s
    const float DEG_TO_RAD = static_cast<float>(M_PI / 180.0);
    float gx = gx_dps * DEG_TO_RAD;
    float gy = gy_dps * DEG_TO_RAD;
    float gz = gz_dps * DEG_TO_RAD;

    float recipNorm;
    float s0, s1, s2, s3;
    float qDot1, qDot2, qDot3, qDot4;
    float _2q0, _2q1, _2q2, _2q3, _4q0, _4q1, _4q2, _8q1, _8q2, q0q0, q1q1, q2q2, q3q3;

    // Rate of change of quaternion from gyroscope
    qDot1 = 0.5f * (-m_q1 * gx - m_q2 * gy - m_q3 * gz);
    qDot2 = 0.5f * ( m_q0 * gx + m_q2 * gz - m_q3 * gy);
    qDot3 = 0.5f * ( m_q0 * gy - m_q1 * gz + m_q3 * gx);
    qDot4 = 0.5f * ( m_q0 * gz + m_q1 * gy - m_q2 * gx);

    // Compute feedback only if accelerometer measurement is valid
    if (!((ax_g == 0.0f) && (ay_g == 0.0f) && (az_g == 0.0f))) {
        // Normalise accelerometer measurement
        recipNorm = inv_sqrt(ax_g * ax_g + ay_g * ay_g + az_g * az_g);
        ax_g *= recipNorm;
        ay_g *= recipNorm;
        az_g *= recipNorm;

        // Auxiliary variables to avoid repeated arithmetic
        _2q0 = 2.0f * m_q0;
        _2q1 = 2.0f * m_q1;
        _2q2 = 2.0f * m_q2;
        _2q3 = 2.0f * m_q3;
        _4q0 = 4.0f * m_q0;
        _4q1 = 4.0f * m_q1;
        _4q2 = 4.0f * m_q2;
        _8q1 = 8.0f * m_q1;
        _8q2 = 8.0f * m_q2;
        q0q0 = m_q0 * m_q0;
        q1q1 = m_q1 * m_q1;
        q2q2 = m_q2 * m_q2;
        q3q3 = m_q3 * m_q3;

        // Gradient descent algorithm corrective step
        s0 = _4q0 * q2q2 + _2q2 * ax_g + _4q0 * q1q1 - _2q1 * ay_g;
        s1 = _4q1 * q3q3 - _2q3 * ax_g + 4.0f * q0q0 * m_q1 - _2q0 * ay_g - _4q1 + _8q1 * q1q1 + _8q1 * q2q2 + _4q1 * az_g;
        s2 = 4.0f * q0q0 * m_q2 + _2q0 * ax_g + _4q2 * q3q3 - _2q3 * ay_g - _4q2 + _8q2 * q1q1 + _8q2 * q2q2 + _4q2 * az_g;
        s3 = 4.0f * q1q1 * m_q3 - _2q1 * ax_g + 4.0f * q2q2 * m_q3 - _2q2 * ay_g;

        recipNorm = inv_sqrt(s0 * s0 + s1 * s1 + s2 * s2 + s3 * s3);
        s0 *= recipNorm;
        s1 *= recipNorm;
        s2 *= recipNorm;
        s3 *= recipNorm;

        // Apply feedback step
        qDot1 -= m_beta * s0;
        qDot2 -= m_beta * s1;
        qDot3 -= m_beta * s2;
        qDot4 -= m_beta * s3;
    }

    // Integrate rate of change of quaternion
    m_q0 += qDot1 * dt;
    m_q1 += qDot2 * dt;
    m_q2 += qDot3 * dt;
    m_q3 += qDot4 * dt;

    // Normalise quaternion
    recipNorm = inv_sqrt(m_q0 * m_q0 + m_q1 * m_q1 + m_q2 * m_q2 + m_q3 * m_q3);
    m_q0 *= recipNorm;
    m_q1 *= recipNorm;
    m_q2 *= recipNorm;
    m_q3 *= recipNorm;
}

EulerAngles MadgwickAHRS::get_euler_angles() const {
    EulerAngles angles;
    const float RAD_TO_DEG = static_cast<float>(180.0 / M_PI);

    // Roll (x-axis rotation)
    float sinr_cosp = 2.0f * (m_q0 * m_q1 + m_q2 * m_q3);
    float cosr_cosp = 1.0f - 2.0f * (m_q1 * m_q1 + m_q2 * m_q2);
    angles.roll = std::atan2(sinr_cosp, cosr_cosp) * RAD_TO_DEG;

    // Pitch (y-axis rotation)
    float sinp = 2.0f * (m_q0 * m_q2 - m_q3 * m_q1);
    if (std::abs(sinp) >= 1.0f) {
        angles.pitch = std::copysign(90.0f, sinp); // 90 degrees if out of range
    } else {
        angles.pitch = std::asin(sinp) * RAD_TO_DEG;
    }

    // Yaw (z-axis rotation)
    float siny_cosp = 2.0f * (m_q0 * m_q3 + m_q1 * m_q2);
    float cosy_cosp = 1.0f - 2.0f * (m_q2 * m_q2 + m_q3 * m_q3);
    angles.yaw = std::atan2(siny_cosp, cosy_cosp) * RAD_TO_DEG;

    return angles;
}
