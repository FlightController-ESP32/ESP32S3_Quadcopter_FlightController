#ifndef MPU6500_DRV_H
#define MPU6500_DRV_H

#include <stdint.h>
#include <stdbool.h>
#include <cmath>
#include <vector>
#include "flight_types.h"
#include "config_pins.h"

// ============================================================================
// 2ND ORDER BIQUAD DIGITAL LOW-PASS FILTER (BUTTERWORTH)
// ============================================================================
class BiquadLPF {
public:
    BiquadLPF();
    void init(float cutoff_hz, float sample_rate_hz);
    void set_cutoff(float cutoff_hz);
    float apply(float sample);
    Vector3f apply(const Vector3f& vec);
    void reset();

    float get_cutoff() const { return m_cutoff_hz; }

private:
    void compute_coefficients();

    float m_cutoff_hz;
    float m_sample_rate_hz;

    // Filter coefficients normalized (a0 = 1.0)
    float m_b0, m_b1, m_b2;
    float m_a1, m_a2;

    // Filter delay registers (3 channels for X, Y, Z or scalar)
    float m_x1[3], m_x2[3];
    float m_y1[3], m_y2[3];
};

// ============================================================================
// MPU6500 6-DOF IMU DRIVER
// ============================================================================
#define MPU6500_WHO_AM_I_VAL      0x70
#define MPU6500_WHO_AM_I_ALT      0x68 // Sometimes returned by clone/rebranded chips

// Registers
#define REG_SMPLRT_DIV            0x19
#define REG_CONFIG                0x1A
#define REG_GYRO_CONFIG           0x1B
#define REG_ACCEL_CONFIG          0x1C
#define REG_ACCEL_CONFIG2         0x1D
#define REG_INT_PIN_CFG           0x37
#define REG_INT_ENABLE            0x38
#define REG_INT_STATUS            0x3A
#define REG_ACCEL_XOUT_H          0x3B
#define REG_PWR_MGMT_1            0x6B
#define REG_PWR_MGMT_2            0x6C
#define REG_WHO_AM_I              0x75

class MPU6500Driver {
public:
    MPU6500Driver();

    // Hardware init (I2C 400kHz on ESP32-S3)
    bool init(uint8_t sda_pin = IMU_SDA_PIN, uint8_t scl_pin = IMU_SCL_PIN, uint8_t int_pin = IMU_INT_PIN);

    // Read sensor data
    bool read_raw(int16_t accel_raw[3], int16_t& temp_raw, int16_t gyro_raw[3]);
    bool read_calibrated(Vector3f& accel_g, Vector3f& gyro_dps);
    bool read_filtered(Vector3f& accel_filtered_g, Vector3f& gyro_filtered_dps);

    // Dynamic Filter & Bias Adjustment
    void set_calibration(const CalibrationProfile& profile);
    void set_filter_cutoff(float cutoff_hz);
    void get_biases(Vector3f& accel_bias, Vector3f& gyro_bias) const;

    // Vibration analysis helper (Computes RMS noise on 3 axes over N samples)
    static float compute_rms_vibration(const std::vector<Vector3f>& samples);

    bool is_healthy() const { return m_healthy; }
    uint8_t get_who_am_i() const { return m_who_am_i; }

private:
    bool write_register(uint8_t reg, uint8_t val);
    bool read_registers(uint8_t reg, uint8_t* buffer, size_t len);

    uint8_t m_i2c_addr;
    uint8_t m_who_am_i;
    bool m_healthy;

    // Calibration biases
    Vector3f m_accel_bias;
    Vector3f m_gyro_bias;

    // Filters for Accel & Gyro
    BiquadLPF m_accel_filter;
    BiquadLPF m_gyro_filter;

    // Scale factors:
    // Gyro FS_SEL=1 (+-500 deg/s) -> 65.5 LSB/(deg/s)
    // Accel AFS_SEL=2 (+-8g) -> 4096 LSB/g
    static constexpr float GYRO_SCALE_DPS = 1.0f / 65.5f;
    static constexpr float ACCEL_SCALE_G  = 1.0f / 4096.0f;
};

#endif // MPU6500_DRV_H
